<h1 align="center">🌙 SilentiumX Tool</h1>

<p>
  
  - Outil en <strong>Français</strong>.<br>
  - Disponible sur <strong>Windows</strong>.<br>
  - <strong>Pas de malware</strong> ou <strong>backdoor</strong>.<br>
  - <strong>Mise à jour fréquente</strong>.<br>
  - <strong>Gratuit</strong> pour tout le monde<br>
  - Les outils comprennent <strong>IP Tools, Roblox Tools, Osint Tools, Website Tools</strong>
  <br><br>
</p>

<h1 align="center">Fonctionnalités</h1>
<p>
   
```
┌── 🌐 - IP Tools
│   ├── IP Analyzer
│   ├── IP Generator
│   ├── Open Port Checker
│   ├── Ping Sniper
│   └── IP Range Scanner
│
├── 🎮 - Roblox Tools
│   ├── Roblox User Lookup
│   ├── Roblox ID Lookup
│   ├── Roblox Update Tracker
│   ├── Roblox Performance Checker
│   └── Roblox Password Generator
│
├── 🔍 - Osint Tools
│   ├── Username Finder
│   ├── Phone Number Checker
│   ├── First Name, Last Name Search
│   ├── Europes City Searcher
│   └── 
│
├── 🌐 - Website Tools
│   ├── Website Scrapper
│   ├── Website Port Scanner
│   ├── Website Infos
│   ├── Website SSL/TLS Validation
│   └── Website XSS Vulnerability Scan
└──
```
<br><br>
</p>

<h1 align="center"></h1>

<h3>Windows:</h3>

<p>
- Installer <a href="https://www.python.org/downloads/">Python</a> avec les options PATH.<br>
- Windows 10 & 11 ou +
</p>

</p>

<h1 align="center">Installation</h1>

Télécharger <a href="https://silentiumx.xyz">SilentiumX</a> Ici

<p>
  
```
1 - Téléchargez le dossier .zip.
2 - Décompressez le dossier.
3 - Lancez « Setup.bat » et « Start.bat ».
```
<br><br>
</p>

<h1 align="center">Avertissement</h1>

<p>
  
  - SilentiumX Tools a été développé uniquement à des fins éducatives.
  - Ce projet a été créé avec de bonnes intentions et est destiné à un usage personnel uniquement.<br>
  - En choisissant d'utiliser SilentiumX, vous reconnaissez et acceptez l'entière responsabilité de toutes les conséquences qui peuvent résulter de vos actions.
</a>
<br><br>
</p>

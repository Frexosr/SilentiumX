import sys
import os
import time
import json
import random
import string
import socket
import sys
import webbrowser
from datetime import datetime

STATE_FILE = "silentiumx_state.json"

def fullscreen():
    import pyautogui
    pyautogui.hotkey('win', 'up')

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')

if not os.path.exists(STATE_FILE):
    with open(STATE_FILE, 'w') as f:
        json.dump({'last_menu': 1}, f)

def save_state(last_menu):
    from colorama import Fore, Style
    red = Fore.RED
    reset = Style.RESET_ALL
    try:
        with open(STATE_FILE, 'w') as f:
            json.dump({'last_menu': last_menu}, f, indent=4)
    except Exception as e:
        print(f"    [{red}x{reset}] {red}-{reset} Erreur lors de la sauvegarde de l'état : {red}{e}{reset}")
        time.sleep(3)
        open(STATE_FILE, 'w').close()

def load_state():
    from colorama import Fore, Style
    red = Fore.RED
    reset = Style.RESET_ALL
    try:
        if os.path.exists(STATE_FILE):
            if os.stat(STATE_FILE).st_size == 0:
                return 1
                
            with open(STATE_FILE, 'r') as f:
                data = json.load(f)
                return data.get('last_menu', 1)
    except json.JSONDecodeError:
        print(f"    [{red}x{reset}] {red}-{reset} Fichier d'état corrompu, réinitialisation...")
        return 1
    except Exception as e:
        print(f"    [{red}x{reset}] {red}-{reset} Erreur lors du chargement de l'état : {red}{e}{reset}")
        return 1
    return 1

def display_menu():
    clear()
    from colorama import Fore, Style
    red = Fore.RED
    reset = Style.RESET_ALL
    menu_lines = [
        f"{red}",
        f"                           ██████  ██▓ ██▓    ▓█████  ███▄    █ ▄▄▄█████▓ ██▓ █    ██  ███▄ ▄███▓▒██   ██▒",
        f"                         ▒██    ▒ ▓██▒▓██▒    ▓█   ▀  ██ ▀█   █ ▓  ██▒ ▓▒▓██▒ ██  ▓██▒▓██▒▀█▀ ██▒▒▒ █ █ ▒░",
        f"                         ░ ▓██▄   ▒██▒▒██░    ▒███   ▓██  ▀█ ██▒▒ ▓██░ ▒░▒██▒▓██  ▒██░▓██    ▓██░░░  █   ░",
        f"                         ▒     ██▒░██░▒██░    ▒▓█  ▄ ▓██▒  ▐▌██▒░ ▓██▓ ░ ░██░▓▓█  ░██░▒██    ▒██  ░ █ █ ▒ ",
        f"                         ▒██████▒▒░██░░██████▒░▒████▒▒██░   ▓██░  ▒██▒ ░ ░██░▒▒█████▓ ▒██▒   ░██▒▒██▒ ▒██▒",
        f"                         ▒ ▒▓▒ ▒ ░░▓  ░ ▒░▓  ░░░ ▒░ ░░ ▒░   ▒ ▒   ▒ ░░   ░▓  ░▒▓▒ ▒ ▒ ░ ▒░   ░  ░▒▒ ░ ░▓ ░",
        f"                         ░ ░▒  ░ ░ ▒ ░░ ░ ▒  ░ ░ ░  ░░ ░░   ░ ▒░    ░     ▒ ░░░▒░ ░ ░ ░  ░      ░░░   ░▒ ░",
        f"                         ░  ░  ░   ▒ ░  ░ ░      ░      ░   ░ ░   ░       ▒ ░ ░░░ ░ ░ ░      ░    ░    ░  ",
        f"                               ░   ░      ░  ░   ░  ░         ░           ░     ░            ░    ░    ░  ",
        f"{reset}",
        f"       {red}┌─{reset} [{red}I{reset}] Info                                                                                                   Next [{red}N{reset}] {red}─┐{reset}  ",
        f"       {red}├─{reset} [{red}S{reset}] Site {red}┌──────────────────┐                                                       ┌──────────────────────┐         │  {reset}",
        f"       {red}└─┬─────────┤{reset}     IP Tools     {red}├───────────────────────────────────────────────────────┤{reset}     Roblox Tools     {red}├─────────┴─{reset} ",
        f"         {red}│         └──────────────────┘                                              │        └──────────────────────┘            ",
        f"         {red}├─{reset} [{red}1{reset}] Ip Analyzer                                                          {red}├─{reset} [{red}6{reset}] Roblox User Lookup                    ",
        f"         {red}├─{reset} [{red}2{reset}] Ip Generator (CTRL + C)                                              {red}├─{reset} [{red}7{reset}] Roblox Id Lookup                      ",
        f"         {red}├─{reset} [{red}3{reset}] Open Port Checker                                                    {red}├─{reset} [{red}8{reset}] Roblox Update Tracker                 ",
        f"         {red}├─{reset} [{red}4{reset}] Ping Sniper                                                          {red}├─{reset} [{red}9{reset}] Roblox Performance Checker            ",
        f"         {red}└─{reset} [{red}6{reset}] Ip Range Scanner                                                     {red}└─{reset} [{red}10{reset}] Roblox Promo Codes Generator         ",
        f"",
    ]

    for line in menu_lines:
        sys.stdout.write(line + "\n")
        sys.stdout.flush()
        time.sleep(0.03)

def display_menu2():
    clear()
    from colorama import Fore, Style
    red = Fore.RED
    reset = Style.RESET_ALL
    menu_lines = [
        f"{red}",
        f"                   ██████  ██▓ ██▓    ▓█████  ███▄    █ ▄▄▄█████▓ ██▓ █    ██  ███▄ ▄███▓▒██   ██▒",
        f"                 ▒██    ▒ ▓██▒▓██▒    ▓█   ▀  ██ ▀█   █ ▓  ██▒ ▓▒▓██▒ ██  ▓██▒▓██▒▀█▀ ██▒▒▒ █ █ ▒░",
        f"                 ░ ▓██▄   ▒██▒▒██░    ▒███   ▓██  ▀█ ██▒▒ ▓██░ ▒░▒██▒▓██  ▒██░▓██    ▓██░░░  █   ░",
        f"                 ▒     ██▒░██░▒██░    ▒▓█  ▄ ▓██▒  ▐▌██▒░ ▓██▓ ░ ░██░▓▓█  ░██░▒██    ▒██  ░ █ █ ▒ ",
        f"                 ▒██████▒▒░██░░██████▒░▒████▒▒██░   ▓██░  ▒██▒ ░ ░██░▒▒█████▓ ▒██▒   ░██▒▒██▒ ▒██▒",
        f"                 ▒ ▒▓▒ ▒ ░░▓  ░ ▒░▓  ░░░ ▒░ ░░ ▒░   ▒ ▒   ▒ ░░   ░▓  ░▒▓▒ ▒ ▒ ░ ▒░   ░  ░▒▒ ░ ░▓ ░",
        f"                 ░ ░▒  ░ ░ ▒ ░░ ░ ▒  ░ ░ ░  ░░ ░░   ░ ▒░    ░     ▒ ░░░▒░ ░ ░ ░  ░      ░░░   ░▒ ░",
        f"                 ░  ░  ░   ▒ ░  ░ ░      ░      ░   ░ ░   ░       ▒ ░ ░░░ ░ ░ ░      ░    ░    ░  ",
        f"                       ░   ░      ░  ░   ░  ░         ░           ░     ░            ░    ░    ░  ",
        f"{reset}",
        f"       {red}┌─{reset} [{red}I{reset}] Info                                                                           Back [{red}B{reset}] {red}─┐{reset}",
        f"       {red}├─{reset} [{red}S{reset}] Site {red}┌───────┐                                                       ┌─────────┐         │  {reset}",
        f"       {red}└─┬─────────┤{reset} Osint {red}├───────────────────────────────────────────────────────┤{reset} Website {red}├─────────┴─{reset}",
        f"         {red}│         └───────┘                                              │        └─────────┘",
        f"         {red}├─{reset} [{red}11{reset}] Username Finder                                          {red}├─{reset} [{red}16{reset}] Website Scrapper",
        f"         {red}├─{reset} [{red}12{reset}] Phone Number Checker                                     {red}├─{reset} [{red}17{reset}] Website Port Scanner",
        f"         {red}├─{reset} [{red}13{reset}] First Name, Last Name Search                             {red}├─{reset} [{red}18{reset}] Website Infos",
        f"         {red}├─{reset} [{red}14{reset}] Europe City Searcher                                     {red}├─{reset} [{red}19{reset}] Website SSL/TLS Validation",
        f"         {red}└─{reset} [{red}15{reset}] DNS Lookup                                               {red}└─{reset} [{red}20{reset}] Website XSS Vulnerability Scan",
        f"",
    ]

    for line in menu_lines:
        sys.stdout.write(line + "\n")
        sys.stdout.flush()
        time.sleep(0.03)

def info():
    from colorama import Fore, Style
    red = Fore.RED
    reset = Style.RESET_ALL
    print(f"""
            [{red}+{reset}] Nom de l'outil     :  SilentiumX
            [{red}+{reset}] Type de l'outil    :  Multi-Tools
            [{red}+{reset}] Version            :  1.1
            [{red}+{reset}] Copyright          :  Copyright (c) SilentiumX 'GPL-3.0 license'
            [{red}+{reset}] Codage             :  Python
            [{red}+{reset}] Langue             :  FR
            [{red}+{reset}] Créateur           :  silentlinux.cyber & nuxi3__
            [{red}+{reset}] Plateforme         :  Windows 10/11
            [{red}+{reset}] Site               :  https://silentiumx.xyz
            [{red}+{reset}] GitHub             :  https://github.com/frexosr/SilentiumX-Tool
            [{red}+{reset}] Discord            :  https://discord.gg/WTDhwmzzGG
          """)
    license = input(f"            [{red}?{reset}] {red}-{reset} Souhaitez-vous voir la licence ? (O/N) : ")
    if license.lower() == "o":
        webbrowser.open("https://github.com/Frexosr/SilentiumX-Tool/blob/main/LICENSE")
    else:
        input(f"            [{red}?{reset}] {red}-{reset} Appuyez sur Entrée pour continuer...")

def site():
    from colorama import Fore, Style
    red = Fore.RED
    reset = Style.RESET_ALL
    webbrowser.open("https://silentiumx.xyz")

def option1():
    from colorama import Fore, Style
    import requests
    red = Fore.RED
    reset = Style.RESET_ALL

    ip = input(f"            [{red}?{reset}] {red}-{reset} IP : ")
    fullscreen()

    url = f"https://ipinfo.io/{ip}/json"
    response = requests.get(url)
    
    if response.status_code == 200:
        data = response.json()
        
        ip_info = {
            f"            [{red}+{reset}] {red}-{reset} IP": data.get("ip", "Non disponible"),
            f"            [{red}+{reset}] {red}-{reset} Ville": data.get("city", "Non disponible"),
            f"            [{red}+{reset}] {red}-{reset} Région": data.get("region", "Non disponible"),
            f"            [{red}+{reset}] {red}-{reset} Pays": data.get("country", "Non disponible"),
            f"            [{red}+{reset}] {red}-{reset} Organisation": data.get("org", "Non disponible"),
            f"            [{red}+{reset}] {red}-{reset} ASN": data.get("asn", {}).get("asn", "Non disponible"),
            f"            [{red}+{reset}] {red}-{reset} Nom ASN": data.get("asn", {}).get("name", "Non disponible"),
            f"            [{red}+{reset}] {red}-{reset} Code Postal": data.get("postal", "Non disponible"),
            f"            [{red}+{reset}] {red}-{reset} Localisation": data.get("loc", "Non disponible"),
            f"            [{red}+{reset}] {red}-{reset} Latitude": data.get("loc", "").split(',')[0] if data.get("loc") else "Non disponible",
            f"            [{red}+{reset}] {red}-{reset} Longitude": data.get("loc", "").split(',')[1] if data.get("loc") else "Non disponible",
            f"            [{red}+{reset}] {red}-{reset} Hostname": data.get("hostname", "Non disponible"),
            f"            [{red}+{reset}] {red}-{reset} Mise à jour": data.get("timezone", "Non disponible"),
            f"            [{red}+{reset}] {red}-{reset} Réseau d'IP": data.get("network", "Non disponible"),
            f"            [{red}+{reset}] {red}-{reset} Type de connexion": data.get("connection", {}).get("type", "Non disponible"),
            f"            [{red}+{reset}] {red}-{reset} Organisation (complet)": data.get("org", "Non disponible"),
            f"            [{red}+{reset}] {red}-{reset} Utilisateur": data.get("user", "Non disponible"),
            f"            [{red}+{reset}] {red}-{reset} Statut géolocalisation": "Disponible" if data.get("loc") else "Non disponible",
            f"            [{red}+{reset}] {red}-{reset} Propriétaire de l'IP": data.get("host", "Non disponible"),
            f"            [{red}+{reset}] {red}-{reset} ISP": data.get("isp", "Non disponible"),
            f"            [{red}+{reset}] {red}-{reset} Attributs de géolocalisation": data.get("loc", "Non disponible"),
            f"            [{red}+{reset}] {red}-{reset} Propriétaire ASN": data.get("asn", {}).get("owner", "Non disponible"),
            f"            [{red}+{reset}] {red}-{reset} Services": data.get("services", "Non disponible"),
            f"            [{red}+{reset}] {red}-{reset} Type de service": data.get("type", "Non disponible"),
            f"            [{red}+{reset}] {red}-{reset} Latitude & Longitude": data.get("loc", "Non disponible"),
        }

        for key, value in ip_info.items():
            print(f"{key}: {value}")

        input(f"""
            [{red}!{reset}] {red}-{reset} Appuyez sur Entrée pour continuer...""")
    
    else:
        print(f"            [{red}x{reset}] {red}-{reset} Erreur lors de la récupération des informations. Vérifie l'adresse IP.")
        time.sleep(3)

def option2():
    from colorama import Fore, Style
    red = Fore.RED
    green = Fore.GREEN
    reset = Style.RESET_ALL
    
    def generate_valid_ip():
        return f"192.168.{random.randint(0, 255)}.{random.randint(0, 255)}"

    print(f"            [{red}~{reset}] {red}-{reset} Démarrage du générateur d'IP...")
    time.sleep(1)

    try:
        while True:
            ip = generate_valid_ip()
            print(f"            [{red}+{reset}] {red}-{reset} IP générée : {ip}")

            time.sleep(1)

    except KeyboardInterrupt:
        print(f"            [{red}x{reset}] {red}-{reset} Génération d'IP arrêtée par l'utilisateur.")
        time.sleep(3)

def option3():
    from colorama import Fore, Style
    red = Fore.RED
    green = Fore.GREEN
    reset = Style.RESET_ALL

    common_ports = [22, 80, 443, 21, 23, 25, 110, 143, 3389, 3306, 53, 8080, 445]

    def scan_port(ip, port):
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(1)
            result = sock.connect_ex((ip, port))
            if result == 0:
                return port
            sock.close()
        except socket.error:
            pass
        return None

    def scan_ports(ip):
        open_ports = []
        for port in common_ports:
            open_port = scan_port(ip, port)
            if open_port:
                open_ports.append(open_port)
        return open_ports

    ip = input(f"            [{red}?{reset}] {red}-{reset} IP : ")

    print(f"            [{red}~{reset}] {red}-{reset} Démarrage du scanner des ports les plus utilisés pour l'IP {ip}...")

    open_ports = scan_ports(ip)

    if open_ports:
        print(f"            [{green}+{reset}] {green}-{reset} Ports ouverts sur {ip} : {', '.join(map(str, open_ports))}")
    else:
        print(f"            [{red}x{reset}] {red}-{reset} Aucun port ouvert trouvé sur {ip}.")

    input(f"\n            [{red}!{reset}] Appuyez sur Entrée pour revenir au menu...")

def option4():
    from colorama import Fore, Style
    red = Fore.RED
    green = Fore.GREEN
    reset = Style.RESET_ALL

    ip = input(f"            [{red}?{reset}] {red}-{reset} IP : ")
    
    port_input = input(f"            [{red}?{reset}] {red}-{reset} Entrez le port (appuyez sur Entrée pour utiliser le port par défaut 80) : ")
    port = int(port_input) if port_input else 80
    
    interval = 1

    print(f"\n            [{red}~{reset}] {red}-{reset} Démarrage du ping vers {red}{ip}{reset}:{red}{port}{reset}...")
    print(f"            [{red}~{reset}] {red}-{reset} Appuyez sur {red}CTRL + C{reset} pour arrêter.\n")

    try:
        while True:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(3)
            
            try:
                start_time = time.time()
                
                sock.connect((ip, port))
                
                sock.sendall(b'ping')
                
                response = sock.recv(1024).decode()
                
                end_time = time.time()
                
                ping_time = (end_time - start_time) * 1000
                
                first_line = response.splitlines()[0] if response else "Pas de réponse"
                
                print(f"            [{green}+{reset}] {green}-{reset} Réponse de {green}{ip}{reset}:{green}{port}{reset} - {green}{first_line}{reset} - Temps : {green}{ping_time:.2f} ms{reset}")
            
            except socket.timeout:
                print(f"            [{red}x{reset}] {red}-{reset} La connexion à {red}{ip}{reset}:{red}{port}{reset} a expiré.")
            except socket.error as e:
                print(f"            [{red}x{reset}] {red}-{reset} Erreur de connexion à {red}{ip}{reset}:{red}{port}{reset} : {red}{e}{reset}")
            finally:
                sock.close()
            
            time.sleep(interval)
    
    except KeyboardInterrupt:
        print(f"\n            [{red}+{reset}] {red}-{reset} Ping arrêté par l'utilisateur.")
        time.sleep(3)

def option5():
    from colorama import Fore, Style
    import ipaddress
    red = Fore.RED
    green = Fore.GREEN
    reset = Style.RESET_ALL

    ip = input(f"            [{red}?{reset}] {red}-{reset} Entrez une adresse IP : ").strip()
    subnet = input(f"            [{red}?{reset}] {red}-{reset} Entrez un sous-réseau {red}({reset}ex: 192.168.1.0/24{red}){reset} : ").strip()
    
    try:
        if ipaddress.ip_address(ip) in ipaddress.ip_network(subnet, strict=False):
            print(f"            [{green}+{reset}] {green}-{reset} L'IP {ip} appartient au sous-réseau {green}{subnet}{reset}.")
            input(f"\n            [{red}!{reset}] Appuyez sur Entrée pour revenir au menu...")
        else:
            print(f"            [{red}+{reset}] {red}-{reset} L'IP {ip} n'appartient pas au sous-réseau {red}{subnet}{reset}.")
            input(f"\n            [{red}!{reset}] Appuyez sur Entrée pour revenir au menu...")
    except ValueError:
        print(f"            [{red}x{reset}] {red}-{reset} Adresse IP ou sous-réseau invalide.")
        time.sleep(3)

def option6():
    from colorama import Fore, Style
    import requests
    from datetime import datetime
    red = Fore.RED
    green = Fore.GREEN
    reset = Style.RESET_ALL

    username = input(f"            [{red}?{reset}] {red}-{reset} Entrez un nom d'utilisateur Roblox : ")

    try:
        user_url = "https://users.roblox.com/v1/usernames/users"
        user_data = {"usernames": [username], "excludeBannedUsers": False}
        user_response = requests.post(user_url, json=user_data).json()
        
        if not user_response["data"]:
            print(f"    [{red}x{reset}] {red}-{reset} Utilisateur introuvable.")
            return
        
        user_id = user_response["data"][0]["id"]
        
        profile_url = f"https://users.roblox.com/v1/users/{user_id}"
        profile_info = requests.get(profile_url).json()
        
        created_at_raw = profile_info.get("created", "Inconnu")
        if created_at_raw != "Inconnu":
            created_at = datetime.strptime(created_at_raw, "%Y-%m-%dT%H:%M:%S.%fZ")
            created_at_formatted = created_at.strftime("%Y-%m-%d %H:%M:%S")
        else:
            created_at_formatted = "Inconnu"
        
        friends_url = f"https://friends.roblox.com/v1/users/{user_id}/friends/count"
        friends_count = requests.get(friends_url).json().get("count", 0)
        
        presence_url = "https://presence.roblox.com/v1/presence/users"
        presence_data = {"userIds": [user_id]}
        presence_response = requests.post(presence_url, json=presence_data).json()
        online_status = presence_response.get("userPresences", [{}])[0].get("userPresenceType", "Inconnu")
        
        badges_url = f"https://badges.roblox.com/v1/users/{user_id}/badges"
        badges_info = requests.get(badges_url).json()
        badges = [badge["name"] for badge in badges_info.get("data", [])]
        
        avatar_url = f"https://thumbnails.roblox.com/v1/users/avatar-headshot?userIds={user_id}&size=420x420&format=Png"
        avatar_response = requests.get(avatar_url).json()
        avatar = avatar_response["data"][0].get("imageUrl", "Aucune image trouvée")

        print(f"""            [{red}+{reset}] {red}-{reset} Informations de l'utilisateur Roblox{reset}
        """)
        print(f"            [{red}+{reset}] {red}-{reset} Nom d'utilisateur : {red}{profile_info.get('name', 'Inconnu')}{reset}")
        print(f"            [{red}+{reset}] {red}-{reset} Description : {red}{profile_info.get('description', 'Aucune description')}{reset}")
        print(f"            [{red}+{reset}] {red}-{reset} ID : {red}{user_id}{reset}")
        print(f"            [{red}+{reset}] {red}-{reset} Date de création : {red}{created_at_formatted}{reset}")
        print(f"            [{red}+{reset}] {red}-{reset} Nombre d'amis : {red}{friends_count}{reset}")
        print(f"            [{red}+{reset}] {red}-{reset} Statut en ligne : {red}{'En ligne' if online_status == 2 else 'Hors ligne'}{reset}")
        print(f"            [{red}+{reset}] {red}-{reset} Badges : {red}{', '.join(badges) if badges else 'Aucun badge'}{reset}")
        print(f"            [{red}+{reset}] {red}-{reset} Avatar : {red}{avatar}{reset}")

        input(f"\n            [{red}!{reset}] Appuyez sur Entrée pour revenir au menu...")

    except Exception as e:
        print(f"            [{red}x{reset}] {red}-{reset} Erreur: {str(e)}")
        input(f"\n            [{red}!{reset}] Appuyez sur Entrée pour revenir au menu...")

def option7():
    from colorama import Fore, Style
    import requests
    from datetime import datetime
    red = Fore.RED
    reset = Style.RESET_ALL

    user_id = input(f"            [{red}?{reset}] {red}-{reset} Entrez un ID Roblox : ")
    
    if not user_id.isdigit():
        print(f"            [{red}x{reset}] {red}-{reset} Erreur : L'ID Roblox doit être un nombre.")
        input(f"\n            [{red}!{reset}] Appuyez sur Entrée pour revenir au menu...")
        return

    user_url = f"https://users.roblox.com/v1/users/{user_id}"
    friends_url = f"https://friends.roblox.com/v1/users/{user_id}/friends/count"
    followers_url = f"https://friends.roblox.com/v1/users/{user_id}/followers/count"
    followings_url = f"https://friends.roblox.com/v1/users/{user_id}/followings/count"
    badges_url = f"https://badges.roblox.com/v1/users/{user_id}/badges"
    groups_url = f"https://groups.roblox.com/v2/users/{user_id}/groups/roles"
    presence_url = "https://presence.roblox.com/v1/presence/users"
    avatar_url = f"https://thumbnails.roblox.com/v1/users/avatar-headshot?userIds={user_id}&size=420x420&format=Png"
    bust_url = f"https://thumbnails.roblox.com/v1/users/avatar-bust?userIds={user_id}&size=420x420&format=Png"

    try:
        user_response = requests.get(user_url)
        user_response.raise_for_status()
        user_data = user_response.json()

        friends_count = requests.get(friends_url).json().get("count", "Non disponible")
        followers_count = requests.get(followers_url).json().get("count", "Non disponible")
        followings_count = requests.get(followings_url).json().get("count", "Non disponible")

        badges_response = requests.get(badges_url)
        badges_data = badges_response.json().get("data", [])
        badges = [badge["name"] for badge in badges_data]

        groups_response = requests.get(groups_url)
        groups_data = groups_response.json().get("data", [])
        groups = [f"{group['group']['name']} (Rôle: {group['role']['name']})" for group in groups_data]

        presence_response = requests.post(presence_url, json={"userIds": [user_id]})
        presence_data = presence_response.json().get("userPresences", [{}])[0]
        online_status = "En ligne" if presence_data.get("userPresenceType") == 2 else "Hors ligne"
        last_online = presence_data.get("lastOnline", "Non disponible")

        avatar_response = requests.get(avatar_url)
        avatar = avatar_response.json()["data"][0].get("imageUrl", "Non disponible")
        bust_response = requests.get(bust_url)
        bust = bust_response.json()["data"][0].get("imageUrl", "Non disponible")

        created_at_raw = user_data.get("created", "Non disponible")
        if created_at_raw != "Non disponible":
            created_at = datetime.strptime(created_at_raw, "%Y-%m-%dT%H:%M:%S.%fZ")
            created_at_formatted = created_at.strftime("%Y-%m-%d %H:%M:%S")
        else:
            created_at_formatted = "Non disponible"

        print(f"""\n            [{red}+{reset}] {red}-{reset} Informations de l'utilisateur Roblox{reset}
        """)
        print(f"            [{red}+{reset}] {red}-{reset} ID : {red}{user_data.get('id', 'Non disponible')}{reset}")
        print(f"            [{red}+{reset}] {red}-{reset} Nom d'utilisateur : {red}{user_data.get('name', 'Non disponible')}{reset}")
        print(f"            [{red}+{reset}] {red}-{reset} Nom affiché : {red}{user_data.get('displayName', 'Non disponible')}{reset}")
        print(f"            [{red}+{reset}] {red}-{reset} Description : {red}{user_data.get('description', 'Non disponible')}{reset}")
        print(f"            [{red}+{reset}] {red}-{reset} Date de création : {red}{created_at_formatted}{reset}")
        print(f"            [{red}+{reset}] {red}-{reset} Statut de bannissement : {red}{'Banni' if user_data.get('isBanned', False) else 'Non banni'}{reset}")
        print(f"            [{red}+{reset}] {red}-{reset} Nombre d'amis : {red}{friends_count}{reset}")
        print(f"            [{red}+{reset}] {red}-{reset} Nombre d'abonnés : {red}{followers_count}{reset}")
        print(f"            [{red}+{reset}] {red}-{reset} Nombre d'abonnements : {red}{followings_count}{reset}")
        print(f"            [{red}+{reset}] {red}-{reset} Badges : {red}{', '.join(badges) if badges else 'Aucun badge'}{reset}")
        print(f"            [{red}+{reset}] {red}-{reset} Groupes : {red}{', '.join(groups) if groups else 'Aucun groupe'}{reset}")
        print(f"            [{red}+{reset}] {red}-{reset} Statut en ligne : {red}{online_status}{reset}")
        print(f"            [{red}+{reset}] {red}-{reset} Dernière activité : {red}{last_online}{reset}")
        print(f"            [{red}+{reset}] {red}-{reset} Avatar : {red}{avatar}{reset}")
        print(f"            [{red}+{reset}] {red}-{reset} Buste : {red}{bust}{reset}")

    except requests.exceptions.RequestException as e:
        print(f"    [{red}x{reset}] {red}-{reset} Erreur : Impossible de récupérer les informations pour l'ID {red}{user_id}{reset}. Erreur : {e}")

    input(f"\n            [{red}!{reset}] Appuyez sur Entrée pour revenir au menu...")

def option8():
    from colorama import Fore, Style
    import webbrowser
    red = Fore.RED
    green = Fore.GREEN
    reset = Style.RESET_ALL

    print(f"            [{red}~{reset}] {red}-{reset} Connexion au blog Roblox...")
    webbrowser.open("https://corp.roblox.com/newsroom")
    time.sleep(3)
    input(f"\n            [{red}!{reset}] Appuyez sur Entrée pour revenir au menu...")

def option9():
    from colorama import Fore, Style
    import psutil
    import matplotlib.pyplot as plt
    red = Fore.RED
    green = Fore.GREEN
    reset = Style.RESET_ALL

    cpu_usage = []
    ram_usage = []
    gpu_usage = []
    timestamps = []

    duration = 30
    interval = 1

    print(f"            [{red}~{reset}] {red}-{reset} Démarrage de l'analyse des performances pendant {duration} secondes...\n")

    start_time = time.time()
    while time.time() - start_time < duration:
        cpu_percent = psutil.cpu_percent(interval=interval)
        ram_percent = psutil.virtual_memory().percent

        cpu_usage.append(cpu_percent)
        ram_usage.append(ram_percent)
        timestamps.append(time.time() - start_time)

        print(f"            [{red}+{reset}] {red}-{reset} Temps écoulé : {int(timestamps[-1])}s - CPU : {red}{cpu_percent}%{reset} - RAM : {green}{ram_percent}%{reset}")

        time.sleep(interval)

    plt.figure(figsize=(10, 6))
    plt.get_current_fig_manager().set_window_title("Résultat de performances de jeu")

    plt.subplot(2, 1, 1)
    plt.plot(timestamps, cpu_usage, label="CPU Usage (%)", color="red")
    plt.title("Utilisation du CPU")
    plt.xlabel("Temps (s)")
    plt.ylabel("CPU (%)")
    plt.grid(True)
    plt.legend()

    plt.subplot(2, 1, 2)
    plt.plot(timestamps, ram_usage, label="RAM Usage (%)", color="green")
    plt.title("Utilisation de la RAM")
    plt.xlabel("Temps (s)")
    plt.ylabel("RAM (%)")
    plt.grid(True)
    plt.legend()

    plt.tight_layout()
    plt.show()

    input(f"\n            [{red}!{reset}] Appuyez sur Entrée pour revenir au menu...")

def option10():
    from colorama import Fore, Style
    red = Fore.RED
    green = Fore.GREEN
    reset = Style.RESET_ALL

    valid_promo_codes = [
        "PROMO12345",
        "0FFERCODE",
        "ROBLOX2023",
        "FREEROBUX",
        "WELCOME123",
        "GIFTCODE99",
        "123456789",
        "FREEITEMS",
        "DISCOUNTCODE",
        "BOGOFREEROBUX",
        "SUMMER2023",
        "WINTER2023",
        "SPRING2023",
        "FALL2023",
        "HALLOWEEN2023",
        "XMAS2023",
        "NEWYEAR2024",
        "VALENTINE2024",
        "EASTER2024",
        "BLACKFRIDAY2023",
        "CYBERMONDAY2023",
        "MEMORIALDAY2024",
    ]

    print(f"            [{red}+{reset}] {red}-{reset} Génération des codes promo Roblox :\n")
    time.sleep(1)

    i = 1
    while True:
        promo_code = ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(10))
        
        is_valid = promo_code in valid_promo_codes
        
        status = f"{green}Valide{reset}" if is_valid else f"{red}Invalide{reset}"
        print(f"            [{red}+{reset}] {red}-{reset} Code promo : {promo_code} | Statut : {status}")

        i += 1
        time.sleep(0.5)

def option11():
    from colorama import Fore, Style
    import requests
    from concurrent.futures import ThreadPoolExecutor
    from fake_useragent import UserAgent
    import urllib.request
    import urllib.error
    red = Fore.RED
    green = Fore.GREEN
    reset = Style.RESET_ALL

    session = requests.Session()
    ua = UserAgent()
    rate_limit_delay = 1

    social_networks = {
        "GitHub": {"url": "https://github.com/{}", "headers": {"Accept": "application/json"}},
        "Twitter": {"url": "https://twitter.com/{}", "headers": {"Accept": "text/html"}},
        "Instagram": {"url": "https://www.instagram.com/{}", "headers": {"Accept": "text/html"}},
        "Reddit": {"url": "https://www.reddit.com/user/{}/about.json", "headers": {"Accept": "application/json"}},
        "TikTok": {"url": "https://www.tiktok.com/@{}", "headers": {"Accept": "text/html"}},
        "Pinterest": {"url": "https://www.pinterest.com/{}", "headers": {"Accept": "text/html"}},
        "Twitch": {"url": "https://www.twitch.tv/{}", "headers": {"Accept": "text/html"}},
        "Medium": {"url": "https://medium.com/@{}", "headers": {"Accept": "text/html"}},
        "DeviantArt": {"url": "https://{}.deviantart.com", "headers": {"Accept": "text/html"}},
        "GitLab": {"url": "https://gitlab.com/{}", "headers": {"Accept": "text/html"}}
    }

    def get_random_headers():
        return {
            "User-Agent": ua.random,
            "Accept-Language": "en-US,en;q=0.9",
            "Accept-Encoding": "gzip, deflate",
            "DNT": "1",
            "Connection": "keep-alive",
        }
    
    def check_profile(network, config, username):
        try:
            headers = {**get_random_headers(), **config["headers"]}
            url = config["url"].format(username)
            response = session.get(url, headers=headers, timeout=10, allow_redirects=False)
            
            exists = False
            if network == "Reddit":
                exists = response.status_code == 200 and "error" not in response.json()
            elif network == "GitHub":
                exists = response.status_code == 200
            else:
                exists = response.status_code in [200, 301, 302]

            return {"network": network, "url": url, "exists": exists, "status_code": response.status_code}
        except requests.RequestException as e:
            return {"network": network, "url": config["url"].format(username), "exists": False, "error": str(e)}
        finally:
            time.sleep(rate_limit_delay)

    username = input(f"\n            [{red}?{reset}] {red}-{reset} Entrez le nom d'utilisateur à rechercher (ou 'q' pour quitter) : ")
    
    if username.lower() == 'q':
        return

    if not username.strip():
        print(f"            [{red}x{reset}] {red}-{reset} Nom d'utilisateur vide.")
        time.sleep(1)
        return

    print(f"\n            [{red}~{reset}] {red}-{reset} Recherche du nom d'utilisateur : {red}{username}{reset}\n")

    try:
        results = []
        with ThreadPoolExecutor(max_workers=5) as executor:
            futures = [executor.submit(check_profile, network, config, username) 
                      for network, config in social_networks.items()]
            
            for future in futures:
                result = future.result()
                if result:
                    results.append(result)

        print("")
        for result in sorted(results, key=lambda x: x["network"]):
            if result.get("exists"):
                print(f"            [{green}+{reset}] {green}-{reset} {result['network']} : {green}{result['url']}{reset} | Statut : {green}Valide{reset}")
            elif "error" in result:
                print(f"            [{red}x{reset}] {red}-{reset} {result['network']} : Erreur - {red}{result['error']}{reset}")
            else:
                print(f"            [{red}x{reset}] {red}-{reset} {result['network']} | Statut : {red}Invalide{reset}")

    except Exception as e:
        print(f"            [{red}x{reset}] {red}-{reset} Erreur lors de la recherche : {e}")

    input(f"\n            [{red}!{reset}] Appuyez sur Entrée pour continuer...")

def option12():
    from colorama import Fore, Style
    import phonenumbers
    from phonenumbers import carrier, timezone, geocoder
    from timezonefinder import TimezoneFinder
    import pytz
    red = Fore.RED
    green = Fore.GREEN
    reset = Style.RESET_ALL

    phone_number = input(f"            [{red}?{reset}] {red}-{reset} Entrez le numéro de téléphone ({red}avec l'indicatif pays, ex: +33123456789{reset}) : ")

    try:
        parsed_number = phonenumbers.parse(phone_number, None)

        if not phonenumbers.is_valid_number(parsed_number):
            print(f"            [{red}x{reset}] {red}-{reset} Erreur : Le numéro de téléphone est invalide.")
            input(f"\n            [{red}!{reset}] Appuyez sur Entrée pour revenir au menu...")
            return

        country_code = parsed_number.country_code
        national_number = parsed_number.national_number
        country = geocoder.description_for_number(parsed_number, "fr")
        operator = carrier.name_for_number(parsed_number, "fr")
        time_zones = timezone.time_zones_for_number(parsed_number)

        print(f"""\n            [{red}+{reset}] {red}-{reset} Informations sur le numéro de téléphone :
              """)
        print(f"            [{red}+{reset}] {red}-{reset} Numéro international : {red}{phonenumbers.format_number(parsed_number, phonenumbers.PhoneNumberFormat.INTERNATIONAL)}{reset}")
        print(f"            [{red}+{reset}] {red}-{reset} Numéro national : {red}{national_number}{reset}")
        print(f"            [{red}+{reset}] {red}-{reset} Indicatif pays : {red}+{country_code}{reset}")
        print(f"            [{red}+{reset}] {red}-{reset} Pays : {red}{country}{reset}")
        print(f"            [{red}+{reset}] {red}-{reset} Opérateur : {red}{operator if operator else 'Inconnu'}{reset}")

        if time_zones:
            time_zone = time_zones[0]
            try:
                tz = pytz.timezone(time_zone)
                current_time = datetime.now(tz).strftime("%H:%M:%S")
                print(f"            [{red}+{reset}] {red}-{reset} Fuseau horaire : {red}{time_zone}{reset}")
                print(f"            [{red}+{reset}] {red}-{reset} Heure locale : {red}{current_time}{reset}")
            except pytz.UnknownTimeZoneError:
                print(f"            [{red}x{reset}] {red}-{reset} Fuseau horaire : {red}Inconnu{reset}")
        else:
            print(f"            [{red}x{reset}] {red}-{reset} Fuseau horaire : {red}Inconnu{reset}")

        region = geocoder.description_for_number(parsed_number, "fr")
        if region:
            print(f"            [{red}+{reset}] {red}-{reset} Région/Ville : {red}{region}{reset}")
        else:
            print(f"            [{red}x{reset}] {red}-{reset} Région/Ville : {red}Inconnu{reset}")

    except phonenumbers.phonenumberutil.NumberParseException:
        print(f"            [{red}x{reset}] {red}-{reset} Erreur : Le format du numéro de téléphone est invalide.")
    except Exception as e:
        print(f"            [{red}x{reset}] {red}-{reset} Erreur : {e}")

    input(f"\n            [{red}!{reset}] Appuyez sur Entrée pour revenir au menu...")

def option13():
    from colorama import Fore, Style
    import urllib.request
    import urllib.error
    green = Fore.GREEN
    red = Fore.RED
    reset = Style.RESET_ALL

    social_networks = {
        "Facebook": "https://www.facebook.com/{}",
        "Twitter": "https://twitter.com/{}",
        "Instagram": "https://www.instagram.com/{}",
        "LinkedIn": "https://www.linkedin.com/in/{}",
        "YouTube": "https://www.youtube.com/{}",
        "Reddit": "https://www.reddit.com/user/{}",
        "Pinterest": "https://www.pinterest.com/{}",
        "TikTok": "https://www.tiktok.com/@{}",
        "Snapchat": "https://www.snapchat.com/add/{}",
        "GitHub": "https://github.com/{}",
        "GitLab": "https://gitlab.com/{}",
        "Twitch": "https://www.twitch.tv/{}",
        "Discord": "https://discord.com/users/{}",
        "Medium": "https://medium.com/@{}",
        "Tumblr": "https://{}.tumblr.com",
        "Flickr": "https://www.flickr.com/people/{}",
        "Vimeo": "https://vimeo.com/{}",
        "Steam": "https://steamcommunity.com/id/{}",
        "DeviantArt": "https://{}.deviantart.com",
        "Behance": "https://www.behance.net/{}",
        "Dribbble": "https://dribbble.com/{}",
        "Goodreads": "https://www.goodreads.com/{}",
        "Last.fm": "https://www.last.fm/user/{}",
        "Foursquare": "https://foursquare.com/{}",
        "Quora": "https://www.quora.com/profile/{}",
        "VK": "https://vk.com/{}",
        "Weibo": "https://www.weibo.com/{}",
        "Xing": "https://www.xing.com/profile/{}",
        "Kickstarter": "https://www.kickstarter.com/profile/{}",
        "Bitbucket": "https://bitbucket.org/{}",
        "Keybase": "https://keybase.io/{}",
        "Slack": "https://{}.slack.com",
        "ReverbNation": "https://www.reverbnation.com/{}",
        "Bandcamp": "https://bandcamp.com/{}",
        "Mixcloud": "https://www.mixcloud.com/{}",
        "Pastebin": "https://pastebin.com/u/{}",
        "Codepen": "https://codepen.io/{}",
        "HackerRank": "https://www.hackerrank.com/{}",
        "LeetCode": "https://leetcode.com/{}",
        "Kaggle": "https://www.kaggle.com/{}",
        "Stack Overflow": "https://stackoverflow.com/users/{}",
        "ResearchGate": "https://www.researchgate.net/profile/{}",
        "Academia.edu": "https://independent.academia.edu/{}",
        "SlideShare": "https://www.slideshare.net/{}",
        "SpeakerDeck": "https://speakerdeck.com/{}",
        "AngelList": "https://angel.co/{}",
        "ProductHunt": "https://www.producthunt.com/@{}",
        "Gumroad": "https://www.gumroad.com/{}",
        "Substack": "https://{}.substack.com",
        "Letterboxd": "https://letterboxd.com/{}",
        "Trakt": "https://trakt.tv/users/{}",
        "IMDb": "https://www.imdb.com/user/{}",
        "RottenTomatoes": "https://www.rottentomatoes.com/user/{}",
        "Fandom": "https://www.fandom.com/u/{}",
        "Wikipedia": "https://en.wikipedia.org/wiki/User:{}",
        "Wikia": "https://{}.fandom.com",
        "Instructables": "https://www.instructables.com/member/{}",
        "Hackaday": "https://hackaday.io/{}",
        "Thingiverse": "https://www.thingiverse.com/{}",
        "GrabCAD": "https://grabcad.com/{}",
        "Cults3D": "https://cults3d.com/en/users/{}",
        "Shapeways": "https://www.shapeways.com/shops/{}",
        "ArtStation": "https://www.artstation.com/{}",
        "500px": "https://500px.com/{}",
        "VSCO": "https://vsco.co/{}",
        "EyeEm": "https://www.eyeem.com/u/{}",
        "Fotolog": "https://www.fotolog.com/{}",
        "SmugMug": "https://{}.smugmug.com",
        "PhotoBucket": "https://photobucket.com/user/{}/library",
        "Pixiv": "https://www.pixiv.net/en/users/{}",
        "Newgrounds": "https://{}.newgrounds.com",
        "CGSociety": "https://www.cgsociety.org/{}",
        "Blender Artists": "https://blenderartists.org/u/{}",
        "ZBrushCentral": "https://www.zbrushcentral.com/user/{}",
        "Polycount": "https://polycount.com/discussion/user/{}",
        "ConceptArt.org": "https://conceptart.org/forums/members/{}/",
        "Coroflot": "https://www.coroflot.com/{}",
        "Carbonmade": "https://{}.carbonmade.com",
        "PortfolioBox": "https://{}.portfoliobox.net",
        "Cargo": "https://{}.cargo.site",
        "Adobe Portfolio": "https://{}.myportfolio.com",
        "Format": "https://{}.format.com",
        "Squarespace": "https://{}.squarespace.com",
        "Wix": "https://{}.wixsite.com/website",
        "Weebly": "https://{}.weebly.com",
        "WordPress": "https://{}.wordpress.com",
        "Blogger": "https://{}.blogspot.com",
        "LiveJournal": "https://{}.livejournal.com",
        "Dreamwidth": "https://{}.dreamwidth.org",
        "JournalFen": "https://{}.journalfen.net",
        "InsaneJournal": "https://{}.insanejournal.com",
        "DeadJournal": "https://{}.deadjournal.com",
        "Diaryland": "https://{}.diaryland.com",
        "OpenDiary": "https://{}.opendiary.com",
        "MySpace": "https://myspace.com/{}",
        "Friendster": "https://www.friendster.com/{}",
        "Hi5": "https://www.hi5.com/{}",
        "Orkut": "https://www.orkut.com/{}",
        "Badoo": "https://badoo.com/{}",
        "Tagged": "https://www.tagged.com/{}",
        "Couchsurfing": "https://www.couchsurfing.com/people/{}",
        "Care2": "https://www.care2.com/{}",
        "Ravelry": "https://www.ravelry.com/people/{}",
        }

    prenom = input(f"            [{red}?{reset}] {red}-{reset} Entrez le prénom : ").strip()
    nom = input(f"            [{red}?{reset}] {red}-{reset} Entrez le nom de famille : ").strip()
    username = f"{prenom.lower()}{nom.lower()}"

    print(f"\n            [{red}~{reset}] {red}-{reset} Recherche {red}OSINT{reset} en cours pour {red}{prenom} {nom}{reset}...\n")
    time.sleep(1)

    def check_account(url_pattern, username):
        url = url_pattern.format(username)
        req = urllib.request.Request(
            url,
            headers={'User-Agent': 'Mozilla/5.0'}
        )
        try:
            with urllib.request.urlopen(req) as response:
                html = response.read().decode('utf-8')
                if "facebook.com" in url and "Ce contenu n'est pas disponible" in html:
                    return False
                elif "twitter.com" in url and "Cette page n'existe pas" in html:
                    return False
                elif "instagram.com" in url and "Désolé, cette page n'est pas disponible" in html:
                
                    return False
                return True
        except urllib.error.HTTPError as e:
            if e.code == 404:
                return False
            return False
        except Exception:
            return False

    found = False
    for name, url_pattern in social_networks.items():
        exists = check_account(url_pattern, username)
        
        if exists:
            print(f"            [{green}+{reset}] {green}-{reset} {green}{name}{reset} - {url_pattern.format(username)} | Statut : {green}Valide{reset}")
            found = True
        else:
            print(f"            [{red}+{reset}] {red}-{reset} {red}{name}{reset} | Statut : {red}Invalide{reset}")
        
        time.sleep(1)

    input(f"\n            [{red}!{reset}] {red}-{reset} Appuyez sur Entrée pour revenir au menu...")

def option14():
    from colorama import Fore, Style
    import webbrowser
    green = Fore.GREEN
    red = Fore.RED
    reset = Style.RESET_ALL

    europe_countries = {
        "france", "allemagne", "espagne", "italie", "portugal", "belgique", "pays-bas", "luxembourg", "suisse",
        "autriche", "suede", "norvege", "danemark", "finlande", "islande", "irlande", "royaume-uni", "pologne",
        "tchequie", "slovaquie", "hongrie", "roumanie", "bulgarie", "grece", "croatie", "serbie", "bosnie",
        "montenegro", "albanie", "macedoine", "slovenie", "lituanie", "lettonie", "estonie", "ukraine",
        "moldavie"
    }
    
    ville = input(f"            [{red}?{reset}] {red}-{reset} Entrez une ville en Europe : ").strip()
    pays = input(f"            [{red}?{reset}] {red}-{reset} Entrez le pays de cette ville : ").strip().lower()
    
    if pays not in europe_countries:
        print(f"            [{red}x{reset}] {red}-{reset} Erreur : Le pays n'est pas en Europe.")
        time.sleep(3)
        return
    
    print(f"            [{red}~{reset}] {red}-{reset} Recherche OSINT sur {red}{ville}{reset}, {red}{pays.capitalize()}{reset}...")
    time.sleep(2)
    print(f"            [{green}+{reset}] {green}-{reset} Recherche OSINT effectué sur {green}{ville}{reset}, {green}{pays.capitalize()}{reset}...")

    google_search_url = f"https://www.google.com/search?q=allintext:{ville}"
    shodan_search_url = f"https://www.shodan.io/search?query={ville}"
    censys_search_url = f"https://search.censys.io/search?resource=hosts&q={ville}"
    
    webbrowser.open(google_search_url)
    webbrowser.open(shodan_search_url)
    webbrowser.open(censys_search_url)
    
    time.sleep(3)
    input(f"\n            [{red}!{reset}] {red}-{reset} Appuyez sur Entrée pour revenir au menu...")

def option15():
    from colorama import Fore, Style
    import socket
    import requests
    from ipwhois import IPWhois
    import tldextract
    import base64
    red = Fore.RED
    reset = Style.RESET_ALL

    target = input(f"            [{red}?{reset}] {red}-{reset} Cible {red}({reset}IP ou domaine{red}){reset} : ").strip()
    
    blocked = [
        "c2lsZW50aXVteC54eXo="
    ]
    blocked_domains = [base64.b64decode(d).decode() for d in blocked]
    clean_extract = tldextract.extract(target)
    clean_domain = f"{clean_extract.domain}.{clean_extract.suffix}".lower()

    if clean_domain in blocked_domains:
        print(f"            [{red}x{reset}] {red}-{reset} Accès Refusé")
        time.sleep(3)
        return

    try:
        ip = socket.gethostbyname(target)
        print(f"\n            [{red}+{reset}] {red}-{reset} IP Résolue : {red}{ip}{reset}")
    except Exception:
        print(f"            [{red}x{reset}] {red}-{reset} Impossible de résoudre la cible.")
        time.sleep(3)
        return
    
    try:
        geo = requests.get(f"http://ip-api.com/json/{ip}").json()
        print(f"""            [{red}+{reset}] {red}-{reset} Pays : {red}{geo.get('country', 'Inconnu')}{reset}
                [{red}+{reset}] {red}-{reset} Ville : {red}{geo.get('city', 'Inconnu')}{reset}
                [{red}+{reset}] {red}-{reset} Org : {red}{geo.get('org', 'Inconnu')}{reset}
                [{red}+{reset}] {red}-{reset} ASN : {red}{geo.get('as', 'Inconnu')}{reset}""")
    except Exception:
        print(f"            [{red}x{reset}] {red}-{reset} Échec géolocalisation.")
    
    try:
        whois = IPWhois(ip).lookup_rdap()
        network = whois.get('network', {})
        print(f"""            [{red}+{reset}] -{reset} Nom réseau : {red}{network.get('name', 'Inconnu')}{reset}
                [{red}+{reset}] {red}-{reset} RIR : {red}{whois.get('nir', 'Inconnu')}{reset}""")
    except Exception:
        print(f"            [{red}x{reset}] {red}-{reset} Échec WHOIS.")

    try:
        rdns = socket.gethostbyaddr(ip)[0]
        print(f"            [{red}+{reset}] - Hostname : {red}{rdns}{reset}")
    except Exception:
        print(f"            [{red}x{reset}] {red}-{reset} Aucun reverse DNS")
    
    ports = [21, 22, 23, 25, 53, 80, 110, 139, 143, 443, 3306]
    open_ports = []
    for port in ports:
        try:
            sock = socket.socket()
            sock.settimeout(0.5)
            if sock.connect_ex((ip, port)) == 0:
                open_ports.append(port)
            sock.close()
        except:
            pass
    if open_ports:
        print(f"            [{red}+{reset}] {red}-{reset} Ports ouverts : {red}{', '.join(map(str, open_ports))}{reset}")
    else:
        print(f"            [{red}x{reset}] {red}-{reset} Aucun port ouvert détecté.")

    input(f"\n            [{red}!{reset}] {red}-{reset} Appuyez sur Entrée pour revenir au menu...")

def option16():
    import os
    import requests
    from bs4 import BeautifulSoup
    from urllib.parse import urljoin, urlparse
    import base64
    import tldextract
    from colorama import Fore, Style

    red = Fore.RED
    green = Fore.GREEN
    reset = Style.RESET_ALL

    raw_url = input(f"            [{red}?{reset}] {red}-{reset} Entrez une URL {red}({reset}ex : https://example.com{red}){reset} : ").strip()

    if not raw_url.startswith(("http://", "https://")):
        raw_url = "https://" + raw_url

    blocked = [
        "c2lsZW50aXVteC54eXo=",
    ]
    blocked_domains = [base64.b64decode(d).decode() for d in blocked]
    clean_extract = tldextract.extract(raw_url)
    clean_domain = f"{clean_extract.domain}.{clean_extract.suffix}".lower()

    if clean_domain in blocked_domains:
        print(f"            [{red}x{reset}] {red}-{reset} Accès Refusé")
        time.sleep(3)
        return

    parsed_url = urlparse(raw_url)
    domain = parsed_url.netloc.lstrip("www.")
    base_url = f"{parsed_url.scheme}://{domain}"

    save_dir = os.path.join("..", "Output", domain)
    os.makedirs(save_dir, exist_ok=True)

    extensions = {".html", ".css", ".js", ".png", ".jpg", ".jpeg", ".gif", ".svg", ".ico", ".woff", ".woff2", ".ttf"}
    to_visit = {base_url}
    visited = set()

    def download_file(url, folder):
        try:
            response = requests.get(url, stream=True)
            response.raise_for_status()

            path = urlparse(url).path
            if path.endswith("/") or not os.path.splitext(path)[1]:
                path += "index.html"
            filename = os.path.join(folder, path.lstrip("/")).split("?")[0]

            os.makedirs(os.path.dirname(filename), exist_ok=True)

            with open(filename, "wb") as f:
                for chunk in response.iter_content(1024):
                    f.write(chunk)

            print(f"            [{green}+{reset}] {green}-{reset}  Téléchargé : {green}{url}{reset}")

        except Exception as e:
            print(f"            [{red}x{reset}] {red}-{reset}  Erreur téléchargement {red}'{reset}{url}{red}'{reset} : {red}{e}{reset}")

    while to_visit:
        url = to_visit.pop()
        if url in visited:
            continue
        visited.add(url)

        try:
            response = requests.get(url)
            response.raise_for_status()
            soup = BeautifulSoup(response.text, "html.parser")
            download_file(url, save_dir)

            for tag in soup.find_all(["a", "link", "script", "img"]):
                attr = "href" if tag.name in ["a", "link"] else "src"
                file_url = tag.get(attr)
                if file_url:
                    file_url = urljoin(url, file_url)
                    parsed = urlparse(file_url)

                    if parsed.netloc.lstrip("www.") == domain and parsed.path:
                        ext = os.path.splitext(parsed.path)[1].split("?")[0]
                        if ext in extensions or tag.name == "a":
                            to_visit.add(file_url)
        except Exception as e:
            print(f"            [{red}x{reset}] {red}-{reset}  Erreur accès {red}'{reset}{url}{red}'{reset} : {red}{e}{reset}")

    print(f"            [{green}+{reset}] {green}-{reset}  Résultat disponible sur : {green}'{reset}../Output/{domain}{green}'{reset}")
    input(f"\n            [{red}!{reset}] {red}-{reset} Appuyez sur Entrée pour revenir au menu...")

def option17():
    from colorama import Fore, Style
    import socket
    import re
    import base64
    import tldextract
    from urllib.parse import urlparse

    red = Fore.RED
    green = Fore.GREEN
    reset = Style.RESET_ALL

    url_regex = re.compile(r'^(?:http://|https://)?(?:www\.)?[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$')

    while True:
        raw_url = input(f"            [{red}?{reset}] {red}-{reset} Entrez une URL {red}({reset}ex: https://example.com{red}){reset} : ").strip()

        if url_regex.match(raw_url):
            if not raw_url.startswith(("http://", "https://")):
                raw_url = "https://" + raw_url

            encoded_blocked = [
                "c2lsZW50aXVteC54eXo=",
            ]
            blocked_domains = [base64.b64decode(d).decode() for d in encoded_blocked]
            clean_extract = tldextract.extract(raw_url)
            clean_domain = f"{clean_extract.domain}.{clean_extract.suffix}".lower()

            if clean_domain in blocked_domains:
                print(f"            [{red}x{reset}] {red}-{reset} Accès Refusé")
                time.sleep(3)
                return

            break
        else:
            print(f"            [{red}x{reset}] {red}-{reset} URL invalide. Veuillez entrer une URL avec un nom de domaine valide.")

    parsed_url = urlparse(raw_url)
    domain = parsed_url.netloc or parsed_url.path
    domain = domain.lstrip("www.")

    while True:
        port_range = input(f"            [{red}?{reset}] {red}-{reset} Entrez la plage de ports {red}({reset}ex: 80;150{red}){reset} : ").strip()

        if re.match(r'^\d+;\d+$', port_range):
            start_port, end_port = map(int, port_range.split(';'))
            if 1 <= start_port <= 65535 and 1 <= end_port <= 65535 and start_port <= end_port:
                break
        print(f"            [{red}x{reset}] {red}-{reset} Plage de ports invalide. Veuillez entrer deux nombres entre 1 et 65535 séparés par un ';'.")

    print(f"            [{green}~{reset}] {green}-{reset} Scanning des ports {start_port} à {end_port} pour {green}'{reset}{domain}{green}'{reset}...")

    open_ports = []

    for port in range(start_port, end_port + 1):
        try:
            sock = socket.create_connection((domain, port), timeout=0.1)
            open_ports.append(port)
            sock.close()
            print(f"            [{green}+{reset}] {green}-{reset} Port {green}{port}{reset} ouvert")
        except:
            pass

    if open_ports:
        print(f"\n            [{green}+{reset}] {green}-{reset} Ports ouverts : {green}{', '.join(map(str, open_ports))}{reset}")
    else:
        print(f"\n            [{red}x{reset}] {red}-{reset} Aucun port ouvert trouvé.")

    input(f"\n            [{red}!{reset}] {red}-{reset} Appuyez sur Entrée pour revenir au menu...")

def option18():
    from colorama import Fore, Style
    import requests
    import socket
    import ssl
    import whois
    from urllib.parse import urlparse
    import re
    import tldextract
    import base64
    red = Fore.RED
    green = Fore.GREEN
    reset = Style.RESET_ALL

    url = input(f"            [{red}+{reset}] {red}-{reset} Entrez une URL ({red}ex : https://example.com{red}){reset} : ").strip()

    if not url.startswith(("http://", "https://")):
        url = "http://" + url

    parsed_url = urlparse(url)
    hostname = parsed_url.netloc or parsed_url.path
    hostname = hostname.lower().replace("www.", "").strip()

    hostname = hostname.split(":")[0]

    extracted = tldextract.extract(url)
    domain_clean = f"{extracted.domain}.{extracted.suffix}".lower()

    encoded_blocked = [
        "c2lsZW50aXVteC54eXo=",
    ]

    blocked_domains = [base64.b64decode(b).decode() for b in encoded_blocked]

    if domain_clean in blocked_domains:
        print(f"            [{red}x{reset}] {red}-{reset} Accès Refusé")
        time.sleep(3)
        return

    fullscreen()

    try:
        print(f"\n            [{green}+{reset}] {green}-{reset}  Domaine : {green}{hostname}{reset}")

        try:
            ip = socket.gethostbyname(hostname)
            print(f"            [{green}+{reset}] {green}-{reset}  Adresse IP : {green}{ip}{reset}")
        except:
            print(f"            [{red}x{reset}] {red}-{reset}  Impossible de résoudre l'adresse IP.")
            time.sleep(1)

        try:
            whois_info = whois.whois(hostname)
            print(f"            [{green}+{reset}] {green}-{reset}  WHOIS :")
            print(f"            [{green}+{reset}] {green}-{reset} Registrar : {green}{whois_info.registrar}{reset}")
            print(f"            [{green}+{reset}] {green}-{reset} Création : {green}{whois_info.creation_date}{reset}")
            print(f"            [{green}+{reset}] {green}-{reset} Expiration : {green}{whois_info.expiration_date}{reset}")
            print(f"            [{green}+{reset}] {green}-{reset} Email : {green}{whois_info.emails}{reset}")
        except:
            print(f"            [{red}x{reset}] {red}-{reset} Impossible d'obtenir les infos WHOIS.")
            time.sleep(1)

        try:
            r = requests.get(url, timeout=5)
            print(f"            [{green}+{reset}] {green}-{reset}  Code HTTP : {r.status_code}")
            print(f"            [{green}+{reset}] {green}-{reset} En-têtes HTTP : ")
            for k, v in r.headers.items():
                print(f"            [{green}+{reset}] {green}-{reset} {green}{k}{reset} : {green}{v}{reset}")
        except:
            print(f"            [{red}+{reset}] {red}-{reset}  Impossible d'accéder à l'URL.")

        try:
            ctx = ssl.create_default_context()
            with ctx.wrap_socket(socket.socket(), server_hostname=hostname) as s:
                s.settimeout(5)
                s.connect((hostname, 443))
                cert = s.getpeercert()
                print(f"            [{green}+{reset}] {green}-{reset} Certificat SSL :")
                print(f"            [{green}+{reset}] {green}-{reset} Sujet : {green}{cert.get('subject')}{reset}")
                print(f"            [{green}+{reset}] {green}-{reset} Émis par : {green}{cert.get('issuer')}{reset}")
                print(f"            [{green}+{reset}] {green}-{reset} Valide du : {green}{cert.get('notBefore')}{reset}")
                print(f"            [{green}+{reset}] {green}-{reset} Valide jusqu'au : {green}{cert.get('notAfter')}{reset}")
        except:
            print(f"            [{red}x{reset}] {red}-{reset} Impossible de récupérer le certificat SSL.")

        try:
            rev_dns = socket.gethostbyaddr(ip)
            print(f"            [{green}+{reset}] {green}-{reset} Reverse DNS : {green}{rev_dns[0]}{reset}")
        except:
            print(f"            [{red}+{reset}] {red}-{reset}  Pas de reverse DNS trouvé.")

        server = r.headers.get("Server", "Inconnu")
        powered = r.headers.get("X-Powered-By", "Inconnu")
        print(f"            [{green}+{reset}] {green}-{reset}  Serveur : {green}{server}{reset}")
        print(f"            [{green}+{reset}] {green}-{reset}  X-Powered-By : {green}{powered}{reset}")

    except Exception as e:
        print(f"            [{red}+{reset}] {red}-{reset} Erreur inattendue : {red}{e}{reset}")
    
    input(f"\n            [{red}!{reset}] {red}-{reset} Appuyez sur Entrée pour revenir au menu...")

def option19():
    from colorama import Fore, Style
    import ssl
    import socket
    from urllib.parse import urlparse

    red = Fore.RED
    green = Fore.GREEN
    reset = Style.RESET_ALL

    hostname = input(f"            [{red}?{reset}] {red}-{reset} Entrez une URL {red}({reset}ex : https://example.com{red}){reset} : ")

    if hostname.startswith('https://'):
        hostname = hostname[8:]
    elif hostname.startswith('http://'):
        hostname = hostname[7:]
    elif hostname.startswith('www.'):
        hostname = hostname[4:]

    if hostname.endswith('/'):
        hostname = hostname[:-1]

    context = ssl.create_default_context()

    try:
        with socket.create_connection((hostname, 443)) as sock:
            with context.wrap_socket(sock, server_hostname=hostname) as ssock:
                ssl_info = ssock.getpeercert()

                subject = ', '.join([item[0][1] for item in ssl_info['subject']])
                issuer = ', '.join([item[0][1] for item in ssl_info['issuer']])

                print(f"            [{green}+{reset}] {green}-{reset} Certificat SSL/TLS récupéré")
                print(f"            [{green}+{reset}] {green}-{reset} Subject : {green}{subject}{reset}")
                print(f"            [{green}+{reset}] {green}-{reset} Issuer : {green}{issuer}{reset}")
                print(f"            [{green}+{reset}] {green}-{reset} Validité : {green}{ssl_info['notAfter']}{reset}")

    except ssl.SSLError as e:
        print(f"            [{red}x{reset}] {red}-{reset} Erreur SSL : ", e)
    except Exception as e:
        print(f"            [{red}x{reset}] {red}-{reset} Erreur de connexion : ", e)

    input(f"\n            [{red}!{reset}] {red}-{reset} Appuyez sur Entrée pour revenir au menu...")

def option20():
    from colorama import Fore, Style
    import requests

    red = Fore.RED
    green = Fore.GREEN
    reset = Style.RESET_ALL

    url = input(f"            [{red}?{reset}] {red}-{reset} Entrez l'URL à vérifier {red}({reset}avec paramètres{red}){reset} : ")

    if not url.startswith('http://') and not url.startswith('https://'):
        url = 'http://' + url

    if url.endswith('/'):
        url = url[:-1]

    payloads = ["<script>alert('XSS')</script>", "<img src=x onerror=alert(1)>"]
    
    for payload in payloads:
        if '?' not in url:
            test_url = f"{url}?payload={payload}"
        else:
            test_url = f"{url}&payload={payload}"

        try:
            response = requests.get(test_url)
            if payload in response.text:
                print(f"            [{green}+{reset}] {green}-{reset} Vulnérabilité XSS trouvée sur {green}'{reset}{test_url}{green}'{reset}")
            else:
                print(f"            [{red}+{reset}] {red}-{reset} Aucune vulnérabilité XSS sur {red}'{reset}{test_url}{red}'{reset}")
        except requests.RequestException as e:
            print(f"            [{red}+{reset}] {red}-{reset} Erreur de connexion : {red}{e}{reset}")

    input(f"\n            [{red}!{reset}] {red}-{reset} Appuyez sur Entrée pour revenir au menu...")

def main():
    from colorama import init, Fore, Style
    init()
    
    if not os.path.exists(STATE_FILE):
        with open(STATE_FILE, 'w') as f:
            json.dump({'last_menu': 1}, f)
    
    last_menu = load_state()
    
    try:
        while True:
            try:
                if last_menu == 1:
                    display_menu()
                    choice = input(f"            [{Fore.RED}?{Style.RESET_ALL}] {Fore.RED}-{Style.RESET_ALL} Choisissez une option : {Style.RESET_ALL}").strip().lower()
                    
                    if choice in ["1","2","3","4","5","6","7","8","9","10"]:
                        globals()[f"option{choice}"]()
                    elif choice == "n":
                        last_menu = 2
                    elif choice == "i":
                        info()
                    elif choice == "s":
                        site()
                        save_state(last_menu)
                    else:
                        print(f"            [{Fore.RED}x{Style.RESET_ALL}] Option invalide")
                        time.sleep(1)
                
                elif last_menu == 2:
                    display_menu2()
                    choice = input(f"            [{Fore.RED}?{Style.RESET_ALL}] {Fore.RED}-{Style.RESET_ALL} Choisissez une option : {Style.RESET_ALL}").strip().lower()
                    
                    if choice in [str(x) for x in range(11,21)]:
                        globals()[f"option{choice}"]()
                    elif choice == "b":
                        last_menu = 1
                        save_state(last_menu)
                    elif choice == "i":
                        info()
                    elif choice == "s":
                        site()
                    else:
                        print(f"            [{Fore.RED}x{Style.RESET_ALL}] Option invalide")
                        time.sleep(1)

            except KeyboardInterrupt:
                save_state(last_menu)
                raise
            except Exception as e:
                print(f"            [{Fore.RED}x{Style.RESET_ALL}] Erreur : {Fore.RED}{e}{Style.RESET_ALL}")
                time.sleep(1)
    
    except KeyboardInterrupt:
        save_state(last_menu)
        time.sleep(1)

if __name__ == "__main__":
    main()
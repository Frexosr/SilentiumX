import sys
import os
import time
import json
import random
import string
import socket
import sys
import webbrowser
from datetime import datetime
import pystyle #type:ignore
STATE_FILE = "silentiumx_state.json"

def fullscreen():
    import pyautogui #type:ignore
    pyautogui.hotkey('win', 'up')

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')

if not os.path.exists(STATE_FILE):
    with open(STATE_FILE, 'w') as f:
        json.dump({'last_menu': 1}, f)

def save_state(last_menu):
    from colorama import Fore, Style #type:ignore
    red = Fore.RED
    reset = Style.RESET_ALL
    try:
        with open(STATE_FILE, 'w') as f:
            json.dump({'last_menu': last_menu}, f, indent=4)
    except Exception as e:
        print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"    [x] - Erreur lors de la sauvegarde de l'état : {e}"))
        time.sleep(3)
        open(STATE_FILE, 'w').close()

def load_state():
    from colorama import Fore, Style #type:ignore
    red = Fore.RED
    reset = Style.RESET_ALL
    try:
        if os.path.exists(STATE_FILE):
            if os.stat(STATE_FILE).st_size == 0:
                return 1
                
            with open(STATE_FILE, 'r') as f:
                data = json.load(f)
                return data.get('last_menu', 1)
    except json.JSONDecodeError:
        print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"    [x] - Fichier d'état corrompu, réinitialisation..."))
        time.sleep(3)
        return 1
    except Exception as e:
        print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"    [x] - Erreur lors du chargement de l'état : {e}"))
        time.sleep(3)
        return 1
    return 1

def display_menu():
    clear()
    from colorama import Fore, Style #type:ignore
    red = Fore.RED
    reset = Style.RESET_ALL

    print(""),
    print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"                           ██████  ██▓ ██▓    ▓█████  ███▄    █ ▄▄▄█████▓ ██▓ █    ██  ███▄ ▄███▓▒██   ██▒")),
    print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"                         ▒██    ▒ ▓██▒▓██▒    ▓█   ▀  ██ ▀█   █ ▓  ██▒ ▓▒▓██▒ ██  ▓██▒▓██▒▀█▀ ██▒▒▒ █ █ ▒░"))
    print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"                         ░ ▓██▄   ▒██▒▒██░    ▒███   ▓██  ▀█ ██▒▒ ▓██░ ▒░▒██▒▓██  ▒██░▓██    ▓██░░░  █   ░")),
    print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"                         ▒     ██▒░██░▒██░    ▒▓█  ▄ ▓██▒  ▐▌██▒░ ▓██▓ ░ ░██░▓▓█  ░██░▒██    ▒██  ░ █ █ ▒ ")),
    print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"                         ▒██████▒▒░██░░██████▒░▒████▒▒██░   ▓██░  ▒██▒ ░ ░██░▒▒█████▓ ▒██▒   ░██▒▒██▒ ▒██▒")),
    print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"                         ▒ ▒▓▒ ▒ ░░▓  ░ ▒░▓  ░░░ ▒░ ░░ ▒░   ▒ ▒   ▒ ░░   ░▓  ░▒▓▒ ▒ ▒ ░ ▒░   ░  ░▒▒ ░ ░▓ ░")),
    print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"                         ░ ░▒  ░ ░ ▒ ░░ ░ ▒  ░ ░ ░  ░░ ░░   ░ ▒░    ░     ▒ ░░░▒░ ░ ░ ░  ░      ░░░   ░▒ ░")),
    print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"                         ░  ░  ░   ▒ ░  ░ ░      ░      ░   ░ ░   ░       ▒ ░ ░░░ ░ ░ ░      ░    ░    ░  ")),
    print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"                               ░   ░      ░  ░   ░  ░         ░           ░     ░            ░    ░    ░  ")),
    print(""),
    print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"       ┌─ [I] Info                                                                                                   Next [N] ─┐  ")),
    print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"       ├─ [S] Site ┌──────────────────┐                                                       ┌──────────────────────┐         │  ")),
    print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"       └─┬─────────┤     IP Tools     ├──────────────────────────────────────────────┬────────┤     Roblox Tools     ├─────────┴─ ")),
    print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"         │         └──────────────────┘                                              │        └──────────────────────┘            ")),
    print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"         ├─ [1] Ip Analyzer                                                          ├─ [6] Roblox User Lookup                    ")),
    print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"         ├─ [2] Ip Generator (CTRL + C)                                              ├─ [7] Roblox Id Lookup                      ")),
    print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"         ├─ [3] Open Port Checker                                                    ├─ [8] Roblox Update Tracker                 ")),
    print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"         ├─ [4] Ping Sniper                                                          ├─ [9] Roblox Performance Checker            ")),
    print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"         └─ [5] Ip Range Scanner                                                     └─ [10] Roblox Promo Codes Generator         ")),
    print(""),

def display_menu2():
    clear()
    from colorama import Fore, Style #type:ignore
    red = Fore.RED
    reset = Style.RESET_ALL

    print(""),
    print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"                   ██████  ██▓ ██▓    ▓█████  ███▄    █ ▄▄▄█████▓ ██▓ █    ██  ███▄ ▄███▓▒██   ██▒")),
    print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"                 ▒██    ▒ ▓██▒▓██▒    ▓█   ▀  ██ ▀█   █ ▓  ██▒ ▓▒▓██▒ ██  ▓██▒▓██▒▀█▀ ██▒▒▒ █ █ ▒░")),
    print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"                 ░ ▓██▄   ▒██▒▒██░    ▒███   ▓██  ▀█ ██▒▒ ▓██░ ▒░▒██▒▓██  ▒██░▓██    ▓██░░░  █   ░")),
    print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"                 ▒     ██▒░██░▒██░    ▒▓█  ▄ ▓██▒  ▐▌██▒░ ▓██▓ ░ ░██░▓▓█  ░██░▒██    ▒██  ░ █ █ ▒ ")),
    print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"                 ▒██████▒▒░██░░██████▒░▒████▒▒██░   ▓██░  ▒██▒ ░ ░██░▒▒█████▓ ▒██▒   ░██▒▒██▒ ▒██▒")),
    print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"                 ▒ ▒▓▒ ▒ ░░▓  ░ ▒░▓  ░░░ ▒░ ░░ ▒░   ▒ ▒   ▒ ░░   ░▓  ░▒▓▒ ▒ ▒ ░ ▒░   ░  ░▒▒ ░ ░▓ ░")),
    print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"                 ░ ░▒  ░ ░ ▒ ░░ ░ ▒  ░ ░ ░  ░░ ░░   ░ ▒░    ░     ▒ ░░░▒░ ░ ░ ░  ░      ░░░   ░▒ ░")),
    print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"                 ░  ░  ░   ▒ ░  ░ ░      ░      ░   ░ ░   ░       ▒ ░ ░░░ ░ ░ ░      ░    ░    ░  ")),
    print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"                       ░   ░      ░  ░   ░  ░         ░           ░     ░            ░    ░    ░  ")),
    print(""),
    print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"       ┌─ [I] Info                                                                           Back [B] ─┐")),
    print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"       ├─ [S] Site ┌───────┐                                                       ┌─────────┐         │  ")),
    print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"       └─┬─────────┤ Osint ├──────────────────────────────────────────────┬────────┤ Website ├─────────┴─")),
    print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"         │         └───────┘                                              │        └─────────┘")),
    print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"         ├─ [11] Username Finder                                          ├─ [16] Website Scrapper")),
    print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"         ├─ [12] Phone Number Checker                                     ├─ [17] Website Port Scanner")),
    print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"         ├─ [13] First Name, Last Name Search                             ├─ [18] Website Infos")),
    print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"         ├─ [14] Europe City Searcher                                     ├─ [19] Website SSL/TLS Validation")),
    print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"         └─ [15] DNS Lookup                                               └─ [20] Website XSS Vulnerability Scan")),
    print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"")),

def info():
    from colorama import Fore, Style #type:ignore
    red = Fore.RED
    reset = Style.RESET_ALL
    print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"""
            [+] Nom de l'outil     :  SilentiumX
            [+] Type de l'outil    :  Multi-Tools
            [+] Version            :  1.3
            [+] Copyright          :  Copyright (c) SilentiumX 'GPL-3.0 license'
            [+] Codage             :  Python
            [+] Langue             :  FR
            [+] Créateur           :  silentlinux.cyber & Nuxi
            [+] Plateforme         :  Windows 10/11
            [+] Site               :  https://silentiumx.xyz
            [+] GitHub             :  https://github.com/frexosr/SilentiumX-Tool
            [+] Discord            :  https://discord.gg/WTDhwmzzGG
          """))
    license = input(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [?] - Souhaitez-vous voir la licence ? (O/N) : "))
    if license.lower() == "o":
        webbrowser.open("https://github.com/Frexosr/SilentiumX-Tool/blob/main/LICENSE")
    else:
        input(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [?] - Appuyez sur Entrée pour continuer..."))

def site():
    from colorama import Fore, Style #type:ignore
    red = Fore.RED
    reset = Style.RESET_ALL
    webbrowser.open("https://silentiumx.xyz")

def option1():
    from colorama import Fore, Style  # type:ignore
    import requests  # type:ignore
    import pystyle #type:ignore
    import time

    ip = input(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [?] - IP : "))
    fullscreen()

    url = f"https://ipinfo.io/{ip}/json"
    response = requests.get(url)
    
    if response.status_code == 200:
        data = response.json()

        ip_info = [
            ("IP", data.get("ip", "Non disponible")),
            ("Ville", data.get("city", "Non disponible")),
            ("Région", data.get("region", "Non disponible")),
            ("Pays", data.get("country", "Non disponible")),
            ("Organisation", data.get("org", "Non disponible")),
            ("ASN", data.get("asn", {}).get("asn", "Non disponible")),
            ("Nom ASN", data.get("asn", {}).get("name", "Non disponible")),
            ("Code Postal", data.get("postal", "Non disponible")),
            ("Localisation", data.get("loc", "Non disponible")),
            ("Latitude", data.get("loc", "").split(',')[0] if data.get("loc") else "Non disponible"),
            ("Longitude", data.get("loc", "").split(',')[1] if data.get("loc") else "Non disponible"),
            ("Hostname", data.get("hostname", "Non disponible")),
            ("Mise à jour", data.get("timezone", "Non disponible")),
            ("Réseau d'IP", data.get("network", "Non disponible")),
            ("Type de connexion", data.get("connection", {}).get("type", "Non disponible")),
            ("Organisation (complet)", data.get("org", "Non disponible")),
            ("Utilisateur", data.get("user", "Non disponible")),
            ("Statut géolocalisation", "Disponible" if data.get("loc") else "Non disponible"),
            ("Propriétaire de l'IP", data.get("host", "Non disponible")),
            ("ISP", data.get("isp", "Non disponible")),
            ("Attributs de géolocalisation", data.get("loc", "Non disponible")),
            ("Propriétaire ASN", data.get("asn", {}).get("owner", "Non disponible")),
            ("Services", data.get("services", "Non disponible")),
            ("Type de service", data.get("type", "Non disponible")),
            ("Latitude & Longitude", data.get("loc", "Non disponible")),
        ]

        for label, value in ip_info:
            line = f"            [+] - {label}: {value}"
            print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, line))

        input(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, "\n            [!] - Appuyez sur Entrée pour continuer..."))
    
    else:
        print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, "            [x] - Erreur lors de la récupération des informations. Vérifie l'adresse IP."))
        time.sleep(3)

def option2():
    from colorama import Fore, Style #type:ignore
    red = Fore.RED
    green = Fore.GREEN
    reset = Style.RESET_ALL
    
    def generate_valid_ip():
        return f"192.168.{random.randint(0, 255)}.{random.randint(0, 255)}"

    print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [~] - Démarrage du générateur d'IP..."))
    time.sleep(1)

    try:
        while True:
            ip = generate_valid_ip()
            print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [+] - IP générée : {ip}"))

            time.sleep(1)

    except KeyboardInterrupt:
        print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [x] - Génération d'IP arrêtée par l'utilisateur."))
        time.sleep(3)

def option3():
    from colorama import Fore, Style #type:ignore
    red = Fore.RED
    green = Fore.GREEN
    reset = Style.RESET_ALL

    common_ports = [22, 80, 443, 21, 23, 25, 110, 143, 3389, 3306, 53, 8080, 445]

    def scan_port(ip, port):
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(1)
            result = sock.connect_ex((ip, port))
            if result == 0:
                return port
            sock.close()
        except socket.error:
            pass
        return None

    def scan_ports(ip):
        open_ports = []
        for port in common_ports:
            open_port = scan_port(ip, port)
            if open_port:
                open_ports.append(open_port)
        return open_ports

    ip = input(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [?] - IP : "))

    print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [~] - Démarrage du scanner des ports les plus utilisés pour l'IP {ip}..."))

    open_ports = scan_ports(ip)

    if open_ports:
        print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [+] - Ports ouverts sur {ip} : {', '.join(map(str, open_ports))}"))
    else:
        print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [x] - Aucun port ouvert trouvé sur {ip}."))

    input(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"\n            [!] Appuyez sur Entrée pour revenir au menu..."))

def option4():
    from colorama import Fore, Style #type:ignore
    red = Fore.RED
    green = Fore.GREEN
    reset = Style.RESET_ALL

    ip = input(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [?] - IP : "))
    
    port_input = input(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [?] - Entrez le port (appuyez sur Entrée pour utiliser le port par défaut 80) : "))
    port = int(port_input) if port_input else 80
    
    interval = 1

    print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"\n            [~] - Démarrage du ping vers {ip}:{port}..."))
    print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [~] - Appuyez sur CTRL + C pour arrêter.\n"))

    try:
        while True:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(3)
            
            try:
                start_time = time.time()
                
                sock.connect((ip, port))
                
                sock.sendall(b'ping')
                
                response = sock.recv(1024).decode()
                
                end_time = time.time()
                
                ping_time = (end_time - start_time) * 1000
                
                first_line = response.splitlines()[0] if response else "Pas de réponse"
                
                print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [+] - Réponse de {ip}:{port} - {first_line} - Temps : {ping_time:.2f} ms"))
            
            except socket.timeout:
                print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [x] - La connexion à {ip}:{port} a expiré."))
            except socket.error as e:
                print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [x] - Erreur de connexion à {ip}:{port} : {e}"))
            finally:
                sock.close()
            
            time.sleep(interval)
    
    except KeyboardInterrupt:
        print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"\n            [+] - Ping arrêté par l'utilisateur."))
        time.sleep(3)

def option5():
    from colorama import Fore, Style #type:ignore
    import ipaddress
    red = Fore.RED
    green = Fore.GREEN
    reset = Style.RESET_ALL

    ip = input(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [?] - Entrez une adresse IP : ")).strip()
    subnet = input(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [?] - Entrez un sous-réseau (ex: 192.168.1.0/24) : ")).strip()
    
    try:
        if ipaddress.ip_address(ip) in ipaddress.ip_network(subnet, strict=False):
            print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [+] - L'IP {ip} appartient au sous-réseau {subnet}."))
            input(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"\n            [!] Appuyez sur Entrée pour revenir au menu..."))
        else:
            print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [+] - L'IP {ip} n'appartient pas au sous-réseau {subnet}."))
            input(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"\n            [!] Appuyez sur Entrée pour revenir au menu..."))
    except ValueError:
        print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [x] - Adresse IP ou sous-réseau invalide."))
        time.sleep(3)

def option6():
    from colorama import Fore, Style #type:ignore
    import requests #type:ignore
    from datetime import datetime
    red = Fore.RED
    green = Fore.GREEN
    reset = Style.RESET_ALL

    username = input(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [?] - Entrez un nom d'utilisateur Roblox : "))

    try:
        user_url = "https://users.roblox.com/v1/usernames/users"
        user_data = {"usernames": [username], "excludeBannedUsers": False}
        user_response = requests.post(user_url, json=user_data).json()
        
        if not user_response["data"]:
            print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"    [x] - Utilisateur introuvable."))
            return
        
        user_id = user_response["data"][0]["id"]
        
        profile_url = f"https://users.roblox.com/v1/users/{user_id}"
        profile_info = requests.get(profile_url).json()
        
        created_at_raw = profile_info.get("created", "Inconnu")
        if created_at_raw != "Inconnu":
            created_at = datetime.strptime(created_at_raw, "%Y-%m-%dT%H:%M:%S.%fZ")
            created_at_formatted = created_at.strftime("%Y-%m-%d %H:%M:%S")
        else:
            created_at_formatted = "Inconnu"
        
        friends_url = f"https://friends.roblox.com/v1/users/{user_id}/friends/count"
        friends_count = requests.get(friends_url).json().get("count", 0)
        
        presence_url = "https://presence.roblox.com/v1/presence/users"
        presence_data = {"userIds": [user_id]}
        presence_response = requests.post(presence_url, json=presence_data).json()
        online_status = presence_response.get("userPresences", [{}])[0].get("userPresenceType", "Inconnu")
        
        badges_url = f"https://badges.roblox.com/v1/users/{user_id}/badges"
        badges_info = requests.get(badges_url).json()
        badges = [badge["name"] for badge in badges_info.get("data", [])]
        
        avatar_url = f"https://thumbnails.roblox.com/v1/users/avatar-headshot?userIds={user_id}&size=420x420&format=Png"
        avatar_response = requests.get(avatar_url).json()
        avatar = avatar_response["data"][0].get("imageUrl", "Aucune image trouvée")

        print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"""            [+] - Informations de l'utilisateur Roblox
        """))
        print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [+] - Nom d'utilisateur : {profile_info.get('name', 'Inconnu')}"))
        print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [+] - Description : {profile_info.get('description', 'Aucune description')}"))
        print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [+] - ID : {user_id}"))
        print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [+] - Date de création : {created_at_formatted}"))
        print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [+] - Nombre d'amis : {friends_count}"))
        print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [+] - Statut en ligne : {'En ligne' if online_status == 2 else 'Hors ligne'}"))
        print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [+] - Badges : {', '.join(badges) if badges else 'Aucun badge'}"))
        print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [+] - Avatar : {avatar}"))

        input(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"\n            [!] Appuyez sur Entrée pour revenir au menu..."))

    except Exception as e:
        print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [x] - Erreur: {str(e)}"))
        input(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"\n            [!] Appuyez sur Entrée pour revenir au menu..."))

def option7():
    from colorama import Fore, Style #type:ignore
    import requests #type:ignore
    from datetime import datetime
    red = Fore.RED
    reset = Style.RESET_ALL

    user_id = input(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [?] - Entrez un ID Roblox : "))
    
    if not user_id.isdigit():
        print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [x] - Erreur : L'ID Roblox doit être un nombre."))
        input(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"\n            [!] Appuyez sur Entrée pour revenir au menu..."))
        return

    user_url = f"https://users.roblox.com/v1/users/{user_id}"
    friends_url = f"https://friends.roblox.com/v1/users/{user_id}/friends/count"
    followers_url = f"https://friends.roblox.com/v1/users/{user_id}/followers/count"
    followings_url = f"https://friends.roblox.com/v1/users/{user_id}/followings/count"
    badges_url = f"https://badges.roblox.com/v1/users/{user_id}/badges"
    groups_url = f"https://groups.roblox.com/v2/users/{user_id}/groups/roles"
    presence_url = "https://presence.roblox.com/v1/presence/users"
    avatar_url = f"https://thumbnails.roblox.com/v1/users/avatar-headshot?userIds={user_id}&size=420x420&format=Png"
    bust_url = f"https://thumbnails.roblox.com/v1/users/avatar-bust?userIds={user_id}&size=420x420&format=Png"

    try:
        user_response = requests.get(user_url)
        user_response.raise_for_status()
        user_data = user_response.json()

        friends_count = requests.get(friends_url).json().get("count", "Non disponible")
        followers_count = requests.get(followers_url).json().get("count", "Non disponible")
        followings_count = requests.get(followings_url).json().get("count", "Non disponible")

        badges_response = requests.get(badges_url)
        badges_data = badges_response.json().get("data", [])
        badges = [badge["name"] for badge in badges_data]

        groups_response = requests.get(groups_url)
        groups_data = groups_response.json().get("data", [])
        groups = [f"{group['group']['name']} (Rôle: {group['role']['name']})" for group in groups_data]

        presence_response = requests.post(presence_url, json={"userIds": [user_id]})
        presence_data = presence_response.json().get("userPresences", [{}])[0]
        online_status = "En ligne" if presence_data.get("userPresenceType") == 2 else "Hors ligne"
        last_online = presence_data.get("lastOnline", "Non disponible")

        avatar_response = requests.get(avatar_url)
        avatar = avatar_response.json()["data"][0].get("imageUrl", "Non disponible")
        bust_response = requests.get(bust_url)
        bust = bust_response.json()["data"][0].get("imageUrl", "Non disponible")

        created_at_raw = user_data.get("created", "Non disponible")
        if created_at_raw != "Non disponible":
            created_at = datetime.strptime(created_at_raw, "%Y-%m-%dT%H:%M:%S.%fZ")
            created_at_formatted = created_at.strftime("%Y-%m-%d %H:%M:%S")
        else:
            created_at_formatted = "Non disponible"

        print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"""\n            [+] - Informations de l'utilisateur Roblox
        """))
        print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [+] - ID : {user_data.get('id', 'Non disponible')}"))
        print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [+] - Nom d'utilisateur : {user_data.get('name', 'Non disponible')}"))
        print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [+] - Nom affiché : {user_data.get('displayName', 'Non disponible')}"))
        print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [+] - Description : {user_data.get('description', 'Non disponible')}"))
        print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [+] - Date de création : {created_at_formatted}"))
        print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [+] - Statut de bannissement : {'Banni' if user_data.get('isBanned', False) else 'Non banni'}"))
        print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [+] - Nombre d'amis : {friends_count}"))
        print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [+] - Nombre d'abonnés : {followers_count}"))
        print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [+] - Nombre d'abonnements : {followings_count}"))
        print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [+] - Badges : {', '.join(badges) if badges else 'Aucun badge'}"))
        print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [+] - Groupes : {', '.join(groups) if groups else 'Aucun groupe'}"))
        print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [+] - Statut en ligne : {online_status}"))
        print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [+] - Dernière activité : {last_online}"))
        print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [+] - Avatar : {avatar}"))
        print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [+] - Buste : {bust}"))

    except requests.exceptions.RequestException as e:
        print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"    [x] - Erreur : Impossible de récupérer les informations pour l'ID {user_id}. Erreur : {e}"))

    input(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"\n            [!] Appuyez sur Entrée pour revenir au menu..."))

def option8():
    from colorama import Fore, Style #type:ignore
    import webbrowser
    red = Fore.RED
    green = Fore.GREEN
    reset = Style.RESET_ALL

    print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [~] - Connexion au blog Roblox..."))
    webbrowser.open("https://corp.roblox.com/newsroom")
    time.sleep(3)
    input(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"\n            [!] Appuyez sur Entrée pour revenir au menu..."))

def option9():
    from colorama import Fore, Style #type:ignore
    import psutil #type:ignore
    import matplotlib.pyplot as plt #type:ignore
    red = Fore.RED
    green = Fore.GREEN
    reset = Style.RESET_ALL

    cpu_usage = []
    ram_usage = []
    gpu_usage = []
    timestamps = []

    duration = 30
    interval = 1

    print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [~] - Démarrage de l'analyse des performances pendant {duration} secondes...\n"))

    start_time = time.time()
    while time.time() - start_time < duration:
        cpu_percent = psutil.cpu_percent(interval=interval)
        ram_percent = psutil.virtual_memory().percent

        cpu_usage.append(cpu_percent)
        ram_usage.append(ram_percent)
        timestamps.append(time.time() - start_time)

        print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [+] - Temps écoulé : {int(timestamps[-1])}s - CPU : {cpu_percent}% - RAM : {ram_percent}%"))

        time.sleep(interval)

    plt.figure(figsize=(10, 6))
    plt.get_current_fig_manager().set_window_title("Résultat de performances de jeu")

    plt.subplot(2, 1, 1)
    plt.plot(timestamps, cpu_usage, label="CPU Usage (%)", color="red")
    plt.title("Utilisation du CPU")
    plt.xlabel("Temps (s)")
    plt.ylabel("CPU (%)")
    plt.grid(True)
    plt.legend()

    plt.subplot(2, 1, 2)
    plt.plot(timestamps, ram_usage, label="RAM Usage (%)", color="green")
    plt.title("Utilisation de la RAM")
    plt.xlabel("Temps (s)")
    plt.ylabel("RAM (%)")
    plt.grid(True)
    plt.legend()

    plt.tight_layout()
    plt.show()

    input(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"\n            [!] Appuyez sur Entrée pour revenir au menu..."))

def option10():
    from colorama import Fore, Style #type:ignore
    red = Fore.RED
    green = Fore.GREEN
    reset = Style.RESET_ALL

    valid_promo_codes = [
        "PROMO12345",
        "0FFERCODE",
        "ROBLOX2023",
        "FREEROBUX",
        "WELCOME123",
        "GIFTCODE99",
        "123456789",
        "FREEITEMS",
        "DISCOUNTCODE",
        "BOGOFREEROBUX",
        "SUMMER2023",
        "WINTER2023",
        "SPRING2023",
        "FALL2023",
        "HALLOWEEN2023",
        "XMAS2023",
        "NEWYEAR2024",
        "VALENTINE2024",
        "EASTER2024",
        "BLACKFRIDAY2023",
        "CYBERMONDAY2023",
        "MEMORIALDAY2024",
    ]

    print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [+] - Génération des codes promo Roblox :\n"))
    time.sleep(1)

    i = 1
    while True:
        promo_code = ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(10))
        
        is_valid = promo_code in valid_promo_codes
        
        status = f"Valide" if is_valid else f"Invalide"
        print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [+] - Code promo : {promo_code} | Statut : {status}"))

        i += 1
        time.sleep(0.5)

def option11():
    from colorama import Fore, Style #type:ignore
    import requests #type:ignore
    from concurrent.futures import ThreadPoolExecutor
    from fake_useragent import UserAgent #type:ignore
    import urllib.request
    import urllib.error
    red = Fore.RED
    green = Fore.GREEN
    reset = Style.RESET_ALL

    session = requests.Session()
    ua = UserAgent()
    rate_limit_delay = 1

    social_networks = {
        "GitHub": {"url": "https://github.com/{}", "headers": {"Accept": "application/json"}},
        "Twitter": {"url": "https://twitter.com/{}", "headers": {"Accept": "text/html"}},
        "Instagram": {"url": "https://www.instagram.com/{}", "headers": {"Accept": "text/html"}},
        "Reddit": {"url": "https://www.reddit.com/user/{}/about.json", "headers": {"Accept": "application/json"}},
        "TikTok": {"url": "https://www.tiktok.com/@{}", "headers": {"Accept": "text/html"}},
        "Pinterest": {"url": "https://www.pinterest.com/{}", "headers": {"Accept": "text/html"}},
        "Twitch": {"url": "https://www.twitch.tv/{}", "headers": {"Accept": "text/html"}},
        "Medium": {"url": "https://medium.com/@{}", "headers": {"Accept": "text/html"}},
        "DeviantArt": {"url": "https://{}.deviantart.com", "headers": {"Accept": "text/html"}},
        "GitLab": {"url": "https://gitlab.com/{}", "headers": {"Accept": "text/html"}}
    }

    def get_random_headers():
        return {
            "User-Agent": ua.random,
            "Accept-Language": "en-US,en;q=0.9",
            "Accept-Encoding": "gzip, deflate",
            "DNT": "1",
            "Connection": "keep-alive",
        }
    
    def check_profile(network, config, username):
        try:
            headers = {**get_random_headers(), **config["headers"]}
            url = config["url"].format(username)
            response = session.get(url, headers=headers, timeout=10, allow_redirects=False)
            
            exists = False
            if network == "Reddit":
                exists = response.status_code == 200 and "error" not in response.json()
            elif network == "GitHub":
                exists = response.status_code == 200
            else:
                exists = response.status_code in [200, 301, 302]

            return {"network": network, "url": url, "exists": exists, "status_code": response.status_code}
        except requests.RequestException as e:
            return {"network": network, "url": config["url"].format(username), "exists": False, "error": str(e)}
        finally:
            time.sleep(rate_limit_delay)

    username = input(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"\n            [?] - Entrez le nom d'utilisateur à rechercher (ou 'q' pour quitter) : "))
    
    if username.lower() == 'q':
        return

    if not username.strip():
        print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [x] - Nom d'utilisateur vide."))
        time.sleep(1)
        return

    print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"\n            [~] - Recherche du nom d'utilisateur : {username}\n"))

    try:
        results = []
        with ThreadPoolExecutor(max_workers=5) as executor:
            futures = [executor.submit(check_profile, network, config, username) 
                      for network, config in social_networks.items()]
            
            for future in futures:
                result = future.result()
                if result:
                    results.append(result)

        print("")
        for result in sorted(results, key=lambda x: x["network"]):
            if result.get("exists"):
                print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [+] - {result['network']} : {result['url']} | Statut : Valide"))
            elif "error" in result:
                print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [x] - {result['network']} : Erreur - {result['error']}"))
            else:
                print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [x] - {result['network']} | Statut : Invalide"))

    except Exception as e:
        print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [x] - Erreur lors de la recherche : {e}"))

    input(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"\n            [!] Appuyez sur Entrée pour continuer..."))

def option12():
    from colorama import Fore, Style #type:ignore
    import phonenumbers #type:ignore
    from phonenumbers import carrier, timezone, geocoder #type:ignore
    from timezonefinder import TimezoneFinder #type:ignore
    import pytz #type:ignore
    red = Fore.RED
    green = Fore.GREEN
    reset = Style.RESET_ALL

    phone_number = input(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [?] - Entrez le numéro de téléphone (avec l'indicatif pays, ex: +33123456789) : "))

    try:
        parsed_number = phonenumbers.parse(phone_number, None)

        if not phonenumbers.is_valid_number(parsed_number):
            print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [x] - Erreur : Le numéro de téléphone est invalide."))
            input(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"\n            [!] Appuyez sur Entrée pour revenir au menu..."))
            return

        country_code = parsed_number.country_code
        national_number = parsed_number.national_number
        country = geocoder.description_for_number(parsed_number, "fr")
        operator = carrier.name_for_number(parsed_number, "fr")
        time_zones = timezone.time_zones_for_number(parsed_number)

        print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"""\n            [+] - Informations sur le numéro de téléphone :
              """))
        print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [+] - Numéro international : {phonenumbers.format_number(parsed_number, phonenumbers.PhoneNumberFormat.INTERNATIONAL)}"))
        print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [+] - Numéro national : {national_number}"))
        print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [+] - Indicatif pays : +{country_code}"))
        print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [+] - Pays : {country}"))
        print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [+] - Opérateur : {operator if operator else 'Inconnu'}"))

        if time_zones:
            time_zone = time_zones[0]
            try:
                tz = pytz.timezone(time_zone)
                current_time = datetime.now(tz).strftime("%H:%M:%S")
                print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [+] - Fuseau horaire : {time_zone}"))
                print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [+] - Heure locale : {current_time}"))
            except pytz.UnknownTimeZoneError:
                print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [x] - Fuseau horaire : Inconnu"))
        else:
            print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [x] - Fuseau horaire : Inconnu"))

        region = geocoder.description_for_number(parsed_number, "fr")
        if region:
            print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [+] - Région/Ville : {region}"))
        else:
            print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [x] - Région/Ville : Inconnu"))

    except phonenumbers.phonenumberutil.NumberParseException:
        print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [x] - Erreur : Le format du numéro de téléphone est invalide."))
    except Exception as e:
        print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [x] - Erreur : {e}"))

    input(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"\n            [!] Appuyez sur Entrée pour revenir au menu..."))

def option13():
    from colorama import Fore, Style #type:ignore
    import urllib.request
    import urllib.error
    green = Fore.GREEN
    red = Fore.RED
    reset = Style.RESET_ALL

    social_networks = {
        "Facebook": "https://www.facebook.com/{}",
        "Twitter": "https://twitter.com/{}",
        "Instagram": "https://www.instagram.com/{}",
        "LinkedIn": "https://www.linkedin.com/in/{}",
        "YouTube": "https://www.youtube.com/{}",
        "Reddit": "https://www.reddit.com/user/{}",
        "Pinterest": "https://www.pinterest.com/{}",
        "TikTok": "https://www.tiktok.com/@{}",
        "Snapchat": "https://www.snapchat.com/add/{}",
        "GitHub": "https://github.com/{}",
        "GitLab": "https://gitlab.com/{}",
        "Twitch": "https://www.twitch.tv/{}",
        "Discord": "https://discord.com/users/{}",
        "Medium": "https://medium.com/@{}",
        "Tumblr": "https://{}.tumblr.com",
        "Flickr": "https://www.flickr.com/people/{}",
        "Vimeo": "https://vimeo.com/{}",
        "Steam": "https://steamcommunity.com/id/{}",
        "DeviantArt": "https://{}.deviantart.com",
        "Behance": "https://www.behance.net/{}",
        "Dribbble": "https://dribbble.com/{}",
        "Goodreads": "https://www.goodreads.com/{}",
        "Last.fm": "https://www.last.fm/user/{}",
        "Foursquare": "https://foursquare.com/{}",
        "Quora": "https://www.quora.com/profile/{}",
        "VK": "https://vk.com/{}",
        "Weibo": "https://www.weibo.com/{}",
        "Xing": "https://www.xing.com/profile/{}",
        "Kickstarter": "https://www.kickstarter.com/profile/{}",
        "Bitbucket": "https://bitbucket.org/{}",
        "Keybase": "https://keybase.io/{}",
        "Slack": "https://{}.slack.com",
        "ReverbNation": "https://www.reverbnation.com/{}",
        "Bandcamp": "https://bandcamp.com/{}",
        "Mixcloud": "https://www.mixcloud.com/{}",
        "Pastebin": "https://pastebin.com/u/{}",
        "Codepen": "https://codepen.io/{}",
        "HackerRank": "https://www.hackerrank.com/{}",
        "LeetCode": "https://leetcode.com/{}",
        "Kaggle": "https://www.kaggle.com/{}",
        "Stack Overflow": "https://stackoverflow.com/users/{}",
        "ResearchGate": "https://www.researchgate.net/profile/{}",
        "Academia.edu": "https://independent.academia.edu/{}",
        "SlideShare": "https://www.slideshare.net/{}",
        "SpeakerDeck": "https://speakerdeck.com/{}",
        "AngelList": "https://angel.co/{}",
        "ProductHunt": "https://www.producthunt.com/@{}",
        "Gumroad": "https://www.gumroad.com/{}",
        "Substack": "https://{}.substack.com",
        "Letterboxd": "https://letterboxd.com/{}",
        "Trakt": "https://trakt.tv/users/{}",
        "IMDb": "https://www.imdb.com/user/{}",
        "RottenTomatoes": "https://www.rottentomatoes.com/user/{}",
        "Fandom": "https://www.fandom.com/u/{}",
        "Wikipedia": "https://en.wikipedia.org/wiki/User:{}",
        "Wikia": "https://{}.fandom.com",
        "Instructables": "https://www.instructables.com/member/{}",
        "Hackaday": "https://hackaday.io/{}",
        "Thingiverse": "https://www.thingiverse.com/{}",
        "GrabCAD": "https://grabcad.com/{}",
        "Cults3D": "https://cults3d.com/en/users/{}",
        "Shapeways": "https://www.shapeways.com/shops/{}",
        "ArtStation": "https://www.artstation.com/{}",
        "500px": "https://500px.com/{}",
        "VSCO": "https://vsco.co/{}",
        "EyeEm": "https://www.eyeem.com/u/{}",
        "Fotolog": "https://www.fotolog.com/{}",
        "SmugMug": "https://{}.smugmug.com",
        "PhotoBucket": "https://photobucket.com/user/{}/library",
        "Pixiv": "https://www.pixiv.net/en/users/{}",
        "Newgrounds": "https://{}.newgrounds.com",
        "CGSociety": "https://www.cgsociety.org/{}",
        "Blender Artists": "https://blenderartists.org/u/{}",
        "ZBrushCentral": "https://www.zbrushcentral.com/user/{}",
        "Polycount": "https://polycount.com/discussion/user/{}",
        "ConceptArt.org": "https://conceptart.org/forums/members/{}/",
        "Coroflot": "https://www.coroflot.com/{}",
        "Carbonmade": "https://{}.carbonmade.com",
        "PortfolioBox": "https://{}.portfoliobox.net",
        "Cargo": "https://{}.cargo.site",
        "Adobe Portfolio": "https://{}.myportfolio.com",
        "Format": "https://{}.format.com",
        "Squarespace": "https://{}.squarespace.com",
        "Wix": "https://{}.wixsite.com/website",
        "Weebly": "https://{}.weebly.com",
        "WordPress": "https://{}.wordpress.com",
        "Blogger": "https://{}.blogspot.com",
        "LiveJournal": "https://{}.livejournal.com",
        "Dreamwidth": "https://{}.dreamwidth.org",
        "JournalFen": "https://{}.journalfen.net",
        "InsaneJournal": "https://{}.insanejournal.com",
        "DeadJournal": "https://{}.deadjournal.com",
        "Diaryland": "https://{}.diaryland.com",
        "OpenDiary": "https://{}.opendiary.com",
        "MySpace": "https://myspace.com/{}",
        "Friendster": "https://www.friendster.com/{}",
        "Hi5": "https://www.hi5.com/{}",
        "Orkut": "https://www.orkut.com/{}",
        "Badoo": "https://badoo.com/{}",
        "Tagged": "https://www.tagged.com/{}",
        "Couchsurfing": "https://www.couchsurfing.com/people/{}",
        "Care2": "https://www.care2.com/{}",
        "Ravelry": "https://www.ravelry.com/people/{}",
        }

    prenom = input(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [?] - Entrez le prénom : ")).strip()
    nom = input(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [?] - Entrez le nom de famille : ")).strip()
    username = f"{prenom.lower()}{nom.lower()}"

    print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"\n            [~] - Recherche OSINT en cours pour {prenom} {nom}...\n"))
    time.sleep(1)

    def check_account(url_pattern, username):
        url = url_pattern.format(username)
        req = urllib.request.Request(
            url,
            headers={'User-Agent': 'Mozilla/5.0'}
        )
        try:
            with urllib.request.urlopen(req) as response:
                html = response.read().decode('utf-8')
                if "facebook.com" in url and "Ce contenu n'est pas disponible" in html:
                    return False
                elif "twitter.com" in url and "Cette page n'existe pas" in html:
                    return False
                elif "instagram.com" in url and "Désolé, cette page n'est pas disponible" in html:
                
                    return False
                return True
        except urllib.error.HTTPError as e:
            if e.code == 404:
                return False
            return False
        except Exception:
            return False

    found = False
    for name, url_pattern in social_networks.items():
        exists = check_account(url_pattern, username)
        
        if exists:
            print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [+] - {name} - {url_pattern.format(username)} | Statut : Valide"))
            found = True
        else:
            print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [+] - {name} | Statut : Invalide"))
        
        time.sleep(1)

    input(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"\n            [!] - Appuyez sur Entrée pour revenir au menu..."))

def option14():
    from colorama import Fore, Style #type:ignore
    import webbrowser
    green = Fore.GREEN
    red = Fore.RED
    reset = Style.RESET_ALL

    europe_countries = {
        "france", "allemagne", "espagne", "italie", "portugal", "belgique", "pays-bas", "luxembourg", "suisse",
        "autriche", "suede", "norvege", "danemark", "finlande", "islande", "irlande", "royaume-uni", "pologne",
        "tchequie", "slovaquie", "hongrie", "roumanie", "bulgarie", "grece", "croatie", "serbie", "bosnie",
        "montenegro", "albanie", "macedoine", "slovenie", "lituanie", "lettonie", "estonie", "ukraine",
        "moldavie"
    }
    
    ville = input(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [?] - Entrez une ville en Europe : ")).strip()
    pays = input(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [?] - Entrez le pays de cette ville : ")).strip().lower()
    
    if pays not in europe_countries:
        print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [x] - Erreur : Le pays n'est pas en Europe."))
        time.sleep(3)
        return
    
    print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [~] - Recherche OSINT sur {ville}, {pays.capitalize()}..."))
    time.sleep(2)
    print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [+] - Recherche OSINT effectué sur {ville}, {pays.capitalize()}..."))

    google_search_url = f"https://www.google.com/search?q=allintext:{ville}"
    shodan_search_url = f"https://www.shodan.io/search?query={ville}"
    censys_search_url = f"https://search.censys.io/search?resource=hosts&q={ville}"
    
    webbrowser.open(google_search_url)
    webbrowser.open(shodan_search_url)
    webbrowser.open(censys_search_url)
    
    time.sleep(3)
    input(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"\n            [!] - Appuyez sur Entrée pour revenir au menu..."))

def option15():
    from colorama import Fore, Style #type:ignore
    import socket
    import requests #type:ignore
    from ipwhois import IPWhois #type:ignore
    import tldextract #type:ignore
    import base64
    red = Fore.RED
    reset = Style.RESET_ALL

    target = input(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [?] - Cible (IP ou domaine) : ")).strip()
    
    blocked = [
        "c2lsZW50aXVteC54eXo="
    ]
    blocked_domains = [base64.b64decode(d).decode() for d in blocked]
    clean_extract = tldextract.extract(target)
    clean_domain = f"{clean_extract.domain}.{clean_extract.suffix}".lower()

    if clean_domain in blocked_domains:
        print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [x] - Accès Refusé"))
        time.sleep(3)
        return

    try:
        ip = socket.gethostbyname(target)
        print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"\n            [+] - IP Résolue : {ip}"))
    except Exception:
        print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [x] - Impossible de résoudre la cible."))
        time.sleep(3)
        return
    
    try:
        geo = requests.get(f"http://ip-api.com/json/{ip}").json()
        print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"""            [+] - Pays : {geo.get('country', 'Inconnu')}
                [+] - Ville : {geo.get('city', 'Inconnu')}
                [+] - Org : {geo.get('org', 'Inconnu')}
                [+] - ASN : {geo.get('as', 'Inconnu')}"""))
    except Exception:
        print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [x] - Échec géolocalisation."))
    
    try:
        whois = IPWhois(ip).lookup_rdap()
        network = whois.get('network', {})
        print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"""            [+] - Nom réseau : {network.get('name', 'Inconnu')}
                [+] - RIR : {whois.get('nir', 'Inconnu')}"""))
    except Exception:
        print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [x] - Échec WHOIS."))

    try:
        rdns = socket.gethostbyaddr(ip)[0]
        print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [+] - Hostname : {rdns}"))
    except Exception:
        print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [x] - Aucun reverse DNS"))
    
    ports = [21, 22, 23, 25, 53, 80, 110, 139, 143, 443, 3306]
    open_ports = []
    for port in ports:
        try:
            sock = socket.socket()
            sock.settimeout(0.5)
            if sock.connect_ex((ip, port)) == 0:
                open_ports.append(port)
            sock.close()
        except:
            pass
    if open_ports:
        print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [+] - Ports ouverts : {', '.join(map(str, open_ports))}"))
    else:
        print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [x] - Aucun port ouvert détecté."))

    input(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"\n            [!] - Appuyez sur Entrée pour revenir au menu..."))

def option16():
    import os
    import requests #type:ignore
    from bs4 import BeautifulSoup #type:ignore
    from urllib.parse import urljoin, urlparse
    import base64
    import tldextract #type:ignore
    from colorama import Fore, Style #type:ignore

    red = Fore.RED
    green = Fore.GREEN
    reset = Style.RESET_ALL

    raw_url = input(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [?] - Entrez une URL (ex : https://example.com) : ")).strip()

    if not raw_url.startswith(("http://", "https://")):
        raw_url = "https://" + raw_url

    blocked = [
        "c2lsZW50aXVteC54eXo=",
    ]
    blocked_domains = [base64.b64decode(d).decode() for d in blocked]
    clean_extract = tldextract.extract(raw_url)
    clean_domain = f"{clean_extract.domain}.{clean_extract.suffix}".lower()

    if clean_domain in blocked_domains:
        print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [x] - Accès Refusé"))
        time.sleep(3)
        return

    parsed_url = urlparse(raw_url)
    domain = parsed_url.netloc.lstrip("www.")
    base_url = f"{parsed_url.scheme}://{domain}"

    save_dir = os.path.join("..", "Output", domain)
    os.makedirs(save_dir, exist_ok=True)

    extensions = {".html", ".css", ".js", ".png", ".jpg", ".jpeg", ".gif", ".svg", ".ico", ".woff", ".woff2", ".ttf"}
    to_visit = {base_url}
    visited = set()

    def download_file(url, folder):
        try:
            response = requests.get(url, stream=True)
            response.raise_for_status()

            path = urlparse(url).path
            if path.endswith("/") or not os.path.splitext(path)[1]:
                path += "index.html"
            filename = os.path.join(folder, path.lstrip("/")).split("?")[0]

            os.makedirs(os.path.dirname(filename), exist_ok=True)

            with open(filename, "wb") as f:
                for chunk in response.iter_content(1024):
                    f.write(chunk)

            print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [+] -  Téléchargé : {url}"))

        except Exception as e:
            print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [x] -  Erreur téléchargement '{url}' : {e}"))

    while to_visit:
        url = to_visit.pop()
        if url in visited:
            continue
        visited.add(url)

        try:
            response = requests.get(url)
            response.raise_for_status()
            soup = BeautifulSoup(response.text, "html.parser")
            download_file(url, save_dir)

            for tag in soup.find_all(["a", "link", "script", "img"]):
                attr = "href" if tag.name in ["a", "link"] else "src"
                file_url = tag.get(attr)
                if file_url:
                    file_url = urljoin(url, file_url)
                    parsed = urlparse(file_url)

                    if parsed.netloc.lstrip("www.") == domain and parsed.path:
                        ext = os.path.splitext(parsed.path)[1].split("?")[0]
                        if ext in extensions or tag.name == "a":
                            to_visit.add(file_url)
        except Exception as e:
            print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [x] -  Erreur accès '{url}' : {e}"))

    print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [+] -  Résultat disponible sur : '../Output/{domain}'"))
    input(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"\n            [!] - Appuyez sur Entrée pour revenir au menu..."))

def option17():
    from colorama import Fore, Style #type:ignore
    import socket
    import re
    import base64
    import tldextract #type:ignore
    from urllib.parse import urlparse

    red = Fore.RED
    green = Fore.GREEN
    reset = Style.RESET_ALL

    url_regex = re.compile(r'^(?:http://|https://)?(?:www\.)?[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$')

    while True:
        raw_url = input(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [?] - Entrez une URL (ex: https://example.com) : ")).strip()

        if url_regex.match(raw_url):
            if not raw_url.startswith(("http://", "https://")):
                raw_url = "https://" + raw_url

            encoded_blocked = [
                "c2lsZW50aXVteC54eXo=",
            ]
            blocked_domains = [base64.b64decode(d).decode() for d in encoded_blocked]
            clean_extract = tldextract.extract(raw_url)
            clean_domain = f"{clean_extract.domain}.{clean_extract.suffix}".lower()

            if clean_domain in blocked_domains:
                print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [x] - Accès Refusé"))
                time.sleep(3)
                return

            break
        else:
            print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [x] - URL invalide. Veuillez entrer une URL avec un nom de domaine valide."))

    parsed_url = urlparse(raw_url)
    domain = parsed_url.netloc or parsed_url.path
    domain = domain.lstrip("www.")

    while True:
        port_range = input(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [?] - Entrez la plage de ports (ex: 80;150) : ")).strip()

        if re.match(r'^\d+;\d+$', port_range):
            start_port, end_port = map(int, port_range.split(';'))
            if 1 <= start_port <= 65535 and 1 <= end_port <= 65535 and start_port <= end_port:
                break
        print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [x] - Plage de ports invalide. Veuillez entrer deux nombres entre 1 et 65535 séparés par un ';'."))

    print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [~] - Scanning des ports {start_port} à {end_port} pour '{domain}'..."))

    open_ports = []

    for port in range(start_port, end_port + 1):
        try:
            sock = socket.create_connection((domain, port), timeout=0.1)
            open_ports.append(port)
            sock.close()
            print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [+] - Port {port} ouvert"))
        except:
            pass

    if open_ports:
        print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"\n            [+] - Ports ouverts : {', '.join(map(str, open_ports))}"))
    else:
        print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"\n            [x] - Aucun port ouvert trouvé."))

    input(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"\n            [!] - Appuyez sur Entrée pour revenir au menu..."))

def option18():
    from colorama import Fore, Style #type:ignore
    import requests #type:ignore
    import socket
    import ssl
    import whois #type:ignore
    from urllib.parse import urlparse
    import re
    import tldextract #type:ignore
    import base64
    red = Fore.RED
    green = Fore.GREEN
    reset = Style.RESET_ALL

    url = input(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [+] - Entrez une URL (ex : https://example.com) : ")).strip()

    if not url.startswith(("http://", "https://")):
        url = "http://" + url

    parsed_url = urlparse(url)
    hostname = parsed_url.netloc or parsed_url.path
    hostname = hostname.lower().replace("www.", "").strip()

    hostname = hostname.split(":")[0]

    extracted = tldextract.extract(url)
    domain_clean = f"{extracted.domain}.{extracted.suffix}".lower()

    encoded_blocked = [
        "c2lsZW50aXVteC54eXo=",
    ]

    blocked_domains = [base64.b64decode(b).decode() for b in encoded_blocked]

    if domain_clean in blocked_domains:
        print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [x] - Accès Refusé"))
        time.sleep(3)
        return

    fullscreen()

    try:
        print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"\n            [+] -  Domaine : {hostname}"))

        try:
            ip = socket.gethostbyname(hostname)
            print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [+] -  Adresse IP : {ip}"))
        except:
            print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [x] -  Impossible de résoudre l'adresse IP."))
            time.sleep(1)

        try:
            whois_info = whois.whois(hostname)
            print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [+] -  WHOIS :"))
            print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [+] - Registrar : {whois_info.registrar}"))
            print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [+] - Création : {whois_info.creation_date}"))
            print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [+] - Expiration : {whois_info.expiration_date}"))
            print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [+] - Email : {whois_info.emails}"))
        except:
            print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [x] - Impossible d'obtenir les infos WHOIS."))
            time.sleep(1)

        try:
            r = requests.get(url, timeout=5)
            print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [+] -  Code HTTP : {r.status_code}"))
            print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [+] - En-têtes HTTP : "))
            for k, v in r.headers.items():
                print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [+] - {k} : {v}"))
        except:
            print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [+] -  Impossible d'accéder à l'URL."))

        try:
            ctx = ssl.create_default_context()
            with ctx.wrap_socket(socket.socket(), server_hostname=hostname) as s:
                s.settimeout(5)
                s.connect((hostname, 443))
                cert = s.getpeercert()
                print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [+] - Certificat SSL :"))
                print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [+] - Sujet : {cert.get('subject')}"))
                print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [+] - Émis par : {cert.get('issuer')}"))
                print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [+] - Valide du : {cert.get('notBefore')}"))
                print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [+] - Valide jusqu'au : {cert.get('notAfter')}"))
        except:
            print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [x] - Impossible de récupérer le certificat SSL."))

        try:
            rev_dns = socket.gethostbyaddr(ip)
            print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [+] - Reverse DNS : {rev_dns[0]}"))
        except:
            print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [+] -  Pas de reverse DNS trouvé."))

        server = r.headers.get("Server", "Inconnu")
        powered = r.headers.get("X-Powered-By", "Inconnu")
        print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [+] -  Serveur : {server}"))
        print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [+] -  X-Powered-By : {powered}"))

    except Exception as e:
        print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [+] - Erreur inattendue : {e}"))
    
    input(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"\n            [!] - Appuyez sur Entrée pour revenir au menu..."))

def option19():
    from colorama import Fore, Style #type:ignore
    import ssl
    import socket
    from urllib.parse import urlparse

    red = Fore.RED
    green = Fore.GREEN
    reset = Style.RESET_ALL

    hostname = input(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [?] - Entrez une URL (ex : https://example.com) : "))

    if hostname.startswith('https://'):
        hostname = hostname[8:]
    elif hostname.startswith('http://'):
        hostname = hostname[7:]
    elif hostname.startswith('www.'):
        hostname = hostname[4:]

    if hostname.endswith('/'):
        hostname = hostname[:-1]

    context = ssl.create_default_context()

    try:
        with socket.create_connection((hostname, 443)) as sock:
            with context.wrap_socket(sock, server_hostname=hostname) as ssock:
                ssl_info = ssock.getpeercert()

                subject = ', '.join([item[0][1] for item in ssl_info['subject']])
                issuer = ', '.join([item[0][1] for item in ssl_info['issuer']])

                print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [+] - Certificat SSL/TLS récupéré"))
                print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [+] - Subject : {subject}"))
                print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [+] - Issuer : {issuer}"))
                print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [+] - Validité : {ssl_info['notAfter']}"))

    except ssl.SSLError as e:
        print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [x] - Erreur SSL : ", e))
    except Exception as e:
        print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [x] - Erreur de connexion : ", e))

    input(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"\n            [!] - Appuyez sur Entrée pour revenir au menu..."))

def option20():
    from colorama import Fore, Style #type:ignore
    import requests #type:ignore

    red = Fore.RED
    green = Fore.GREEN
    reset = Style.RESET_ALL

    url = input(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [?] - Entrez l'URL à vérifier (avec paramètres) : "))

    if not url.startswith('http://') and not url.startswith('https://'):
        url = 'http://' + url

    if url.endswith('/'):
        url = url[:-1]

    payloads = ["<script>alert('XSS')</script>", "<img src=x onerror=alert(1)>"]
    
    for payload in payloads:
        if '?' not in url:
            test_url = f"{url}?payload={payload}"
        else:
            test_url = f"{url}&payload={payload}"

        try:
            response = requests.get(test_url)
            if payload in response.text:
                print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [+] - Vulnérabilité XSS trouvée sur '{test_url}'"))
            else:
                print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [+] - Aucune vulnérabilité XSS sur '{test_url}'"))
        except requests.RequestException as e:
            print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [+] - Erreur de connexion : {e}"))

    input(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"\n            [!] - Appuyez sur Entrée pour revenir au menu..."))

def main():
    from colorama import init, Fore, Style #type:ignore
    init()
    
    if not os.path.exists(STATE_FILE):
        with open(STATE_FILE, 'w') as f:
            json.dump({'last_menu': 1}, f)
    
    last_menu = load_state()
    
    try:
        while True:
            try:
                if last_menu == 1:
                    display_menu()
                    choice = input(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [?] - Choisissez une option : ")).strip().lower()
                    
                    if choice in ["1","2","3","4","5","6","7","8","9","10"]:
                        globals()[f"option{choice}"]()
                    elif choice == "n":
                        last_menu = 2
                    elif choice == "i":
                        info()
                    elif choice == "s":
                        site()
                        save_state(last_menu)
                    else:
                        print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [x] Option invalide"))
                        time.sleep(1)
                
                elif last_menu == 2:
                    display_menu2()
                    choice = input(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [?] - Choisissez une option : ")).strip().lower()
                    
                    if choice in [str(x) for x in range(11,21)]:
                        globals()[f"option{choice}"]()
                    elif choice == "b":
                        last_menu = 1
                        save_state(last_menu)
                    elif choice == "i":
                        info()
                    elif choice == "s":
                        site()
                    else:
                        print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [x] - Option invalide"))
                        time.sleep(1)

            except KeyboardInterrupt:
                save_state(last_menu)
                raise
            except Exception as e:
                print(pystyle.Colorate.Horizontal(pystyle.Colors.blue_to_white, f"            [x] Erreur : {e}"))
                time.sleep(1)
    
    except KeyboardInterrupt:
        save_state(last_menu)
        time.sleep(1)

if __name__ == "__main__":
    main()